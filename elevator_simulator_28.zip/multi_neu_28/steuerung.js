

function fahren(){
  
  for(f=0;f<etagenanzahl;f++){if(dist(fahrkorb.xPos*gg,fahrkorb.yPos*gg,etagen[f].xPos*gg,etagen[f].yPos*gg)<(fahrkorb.fahrkorbhoehe)/2*gg)//verzoegerungsweg*gg)//((fahrkorb.fahrkorbhoehe)/2)*gg)//lege kabinenstandort fest
  {standort[f]=true;standortDez=f;}else{standort[f]=false;}}
  
 
  
  
  this.inspektion=0;//stelle fest, ob einer der inspektionsschalter auf on steht
  for(f=0;f<fahrflasche.length;f++){if(fahrflasche[f].insp){this.inspektion++;}}
  if(this.inspektion===0 ){
  inspektionsgeschwindigkeit=false;
  if(!aussenEin){for(f=0;f<etagenanzahl;f++){aussenauf[f]=false;aussenab[f]=false;}}//__________________________________________________loesche alle aussenrufe, wenn diese abgeschaltet sind
  if(dist(fahrkorb.xPos*gg,fahrkorb.yPos*gg,etagen[standortDez].xPos*gg,etagen[standortDez].yPos*gg)<((fahrkorb.fahrkorbhoehe)/8)*gg)//______________________________________tuerzone erzeugen
  {tuerzone=true;}else{tuerzone=false;}
  distanz=abs((etagen[standortDez].yPos)-(fahrkorb.yPos));
  
   
            
            
            
            if(timer<millis()){
            //______________________________KOMMANDO_ERKENNEN___________________________________________________________________   
            for (g=0;g<standortDez;g++)
            {if((aussenauf[g] || aussenab[g] || innen[g]) && !auf && !langsam){ab=true;schnell=true;stopp=false;}}
            for(g=standortDez+1;g<etagenanzahl;g++)
            {if((aussenauf[g] || aussenab[g] || innen[g]) && !ab && !langsam){auf=true;schnell=true;stopp=false;}}
            }
            
            if(((aussenauf[standortDez] && !ab)|| (aussenab[standortDez] && !auf) || innen[standortDez]) && stopp && tuerzone && !tuerenBleibenZu)//_______________________________________________________tuer oeffnen bei kabine am rufort
            {doorOpen=true;timer=millis()+5000;aussenauf[standortDez]=false;aussenab[standortDez]=false;innen[standortDez]=false;}
            
            //__________________________oeffne_die_tuer_nicht_wenn_du_zu_knapp_stehst____________________________________________________________________________________________________________
            if((aussenauf[standortDez] || aussenab[standortDez] || innen[standortDez]) && !schnell & !langsam && !auf && !ab ) {aussenauf[standortDez]=false;aussenab[standortDez]=false;innen[standortDez]=false;}
            
            
            
            
  
   //___________________FESTLEGEN_OB_EIN_RUF_ABGEARBEITET_WERDEN_SOLL___(_NICHT_ZU_NAH_AN_DER_ETAGE_!_)_____________________________________________ 
    for(f=0;f<etagenanzahl;f++){
    if(aussenauf[f] && !aussenaufBefehl[f] && standortDez!=f){aussenaufBefehl[f]=true;}//nur wenn der ruf ausserhalb der etage gegeben wird, wird er auch direkt in die verarbeitung aufgenommen
    if(aussenab[f] && !aussenabBefehl[f] && standortDez!=f){aussenabBefehl[f]=true;}// dadurch verhindert man "rufe im ruecken". sobald die kabine die betroffene etage verlaesst, wird der ruf
    if(innen[f] && !innenBefehl[f] && standortDez!=f){innenBefehl[f]=true;}          //in die befehlsmatrix kopiert.
  }
                      
 
  
  //________________LIEGEN_NOCH_RUFE_IN_FAHRTRICHTUNG_AN_?___mit_den_addierern_wird_auch_die_sammelrichtung_beeinflusst________________________________________
  
  this.addiererAuf=0;
  this.addiererAb=0;
  if(ab){for(f=0;f<standortDez;f++){this.addiererAb=this.addiererAb+aussenab[f]+aussenauf[f]+innen[f];}}
  if(auf){for(f=standortDez+1;f<etagenanzahl;f++){this.addiererAuf=this.addiererAuf+aussenab[f]+aussenauf[f]+innen[f];}} 
  if(!langsam && !schnell && ab && this.addiererAb===0 && umrichterdaten[0]===0)
  {ab=false;}
  if(!langsam && !schnell && auf && this.addiererAuf===0 && umrichterdaten[0]===0 )
  {auf=false;}
  //__________________________________________________________________________________________________
  
if(dist((etagen[standortDez].xPos+(etagenhoehe/10))*gg,etagen[standortDez].yPos*gg,fahrkorb.xPos*gg,fahrkorb.yPos*gg)<verzoegerungsweg*gg){this.ankunft=true;}else{this.ankunft=false;}//verzoegerungsweg unterschritten?
   
   //__________________________________VERZOEGERN_ETAGE_VORAUS__________ob_der_verzoegerungsweg_erreicht_wurde_wird_in_der_vorherigen_programmzeile_abgefragt_____________________________
       
    if(aussenabBefehl[standortDez]&& ab && this.ankunft) {schnell=false;langsam=true;}
     if(aussenaufBefehl[standortDez]&& ab  && this.addiererAb===0 && this.ankunft) {schnell=false;langsam=true;}
    if(aussenaufBefehl[standortDez] && auf && this.ankunft) {schnell=false;langsam=true;einfahrt=true;}
     if(aussenab[standortDez]&& auf  && this.addiererAuf===0 && this.ankunft){schnell=false;langsam=true;}
     if(innenBefehl[standortDez] && this.ankunft){schnell=false;langsam=true;}
     
   if(langsam ){einfahrt=true;}
   //_____________________________________________________________________________________________________
   
   
    //______________________________ANHALTEN_UND_RUF_LOESCHEN_(_AUCH_BEFEHL_LOESCHEN_)_______________________________________________________
    if(langsam){if(dist((etagen[standortDez].xPos+(etagenhoehe/10))*gg,etagen[standortDez].yPos*gg,fahrkorb.xPos*gg,fahrkorb.yPos*gg)<1)
    {
    if(aussenabBefehl[standortDez]  && ab ){aussenab[standortDez]=false;aussenabBefehl[standortDez]=false;}
    if(aussenaufBefehl[standortDez] && ab  && this.addiererAb===0){aussenauf[standortDez]=false;aussenaufBefehl[standortDez]=false;}
    if(aussenaufBefehl[standortDez] && auf){aussenauf[standortDez]=false;aussenaufBefehl[standortDez]=false;}
    if(aussenabBefehl[standortDez] && auf && this.addiererAuf===0){aussenab[standortDez]=false;aussenabBefehl[standortDez]=false;}
     if(innenBefehl[standortDez]){innen[standortDez]=false;innenBefehl[standortDez]=false;}
    
    
     langsam=false;timer=millis()+5000;stopp=true; if(!tuerenBleibenZu && tuerzone){doorOpen=true;}}} //anhalten und kabinentuer oeffnen     
    //_________________________________________________________________________________________________ 
   
   
   
   
  
 
 if(doorOpen && timer<millis()){doorOpen=false;}// kabinentuer wieder schliessen
    
  } 
  
  //_____________________________________________________INSPEKTIONSSTEUERUNG_MIT_PRIORITAETSERKENNUNG_____________________________________________
  this.chef=0;//welche fahrflasche hat prioritaet?
  
  if(this.inspektion>0 ){
    doorOpen=false;
    for(f=0;f<fahrflasche.length;f++)
    {if(fahrflasche[f].insp && fahrflasche[f].prio===1){this.chef=f;}
     if(fahrflasche[f].insp && fahrflasche[f].prio===2){this.chef=f;}
     if(fahrflasche[f].insp && fahrflasche[f].prio===3){this.chef=f;}
     
  }

  if(!fahrflasche[this.chef].ab){inspektionsgeschwindigkeit=false;}
   if(!fahrflasche[this.chef].auf){inspektionsgeschwindigkeit=false;} 
  
  if(fahrflasche[this.chef].ab &&  fahrflasche[this.chef].zweiter){ab=true;inspektionsgeschwindigkeit=true;stopp=false;auf=false;notstopp=false;}else{stopp=true;}//___________stopp=true nur einmal aufrufen. wird beim loslassen von auf oder ab ausgefuehrt
  if(fahrflasche[this.chef].auf &&  fahrflasche[this.chef].zweiter){auf=true;inspektionsgeschwindigkeit=true;stopp=false;ab=false;notstopp=false;}
  if(fahrflasche[this.chef].prio<3 && (fahrkorb.yPos>((etagenanzahl-1)*etagenhoehe)-SKU-SKU+topfloor) && auf){auf=false;langsam=false;schnell=false;stopp=true;inspektionsgeschwindigkeit=false;}//inspektionsfahrt abschalten 
  if(fahrflasche[this.chef].prio<3 && (fahrkorb.yPos<topfloor+SKO+SKO) && ab){ab=false;langsam=false;schnell=false;stopp=true;inspektionsgeschwindigkeit=false;}//                                             "
  if(fangundgb.eingerastet && fangundgb.auf && fahrflasche[this.chef].prio===3 && fahrflasche[this.chef].ab && fahrflasche[this.chef].zweiter)//_________freifahren aus fang
{ab=true;inspektionsgeschwindigkeit=true;stopp=false;auf=false;fangundgb.eingerastet=false;fangundgb.auf=false;}//                                                    |
  if(fangundgb.eingerastet && fangundgb.ab && fahrflasche[this.chef].prio===3 && fahrflasche[this.chef].auf && fahrflasche[this.chef].zweiter)//                      |
{auf=true;inspektionsgeschwindigkeit=true;stopp=false;ab=false;fangundgb.eingerastet=false;fangundgb.ab=false;}//                                                     V 
   

  } 
  

}
 
  
  //______________________________________A_N_T_R_I_E_B_S_T_E_U_E_R_U_N_G___________________________________________________________
function regelung(){
  
 //beschreibung umrichterdatenfeld:
 //umrichterdaten[0]=aktuelle geschwindigkeit
 //umrichterdaten[1]=schnelle geschwindigkeit
 //umrichterdaten[2]=langsame geschwindigkeit
 //umrichterdaten[3]=inspektionsgeschwindigkeit
 //umrichterdaten[4]=beschleunigung
 //umrichterdaten[5]=verzoegerung
 //umrichterdaten[6]=verzoegerungswert schlussanhalten
 

  
 bremse.oeffnen=false;
 if(ab){this.gegengewicht=-15;}
 if(auf){this.gegengewicht=15;}
 
  if(!stopp && (schnell || langsam) && !ab && !auf){ab=true;} //verhindert, das keine richtung ansteht wenn eine geschwindigkeit vorgewaehlt wurde
  
  if(notstopp ){schnell=false;langsam=false;}
  if(notstopp && umrichterdaten[0]>0 && !bremseDefekt && bremse.hebel<-30){umrichterdaten[0]-=(notstoppverzoegerung+this.gegengewicht)/1000;if(umrichterdaten[0]<0){umrichterdaten[0]=0;notstopp=false;auf=false;ab=false;bremse.manuelleBremsenoeffnung=false;}}//stopp=true; 
  
   if((bremseDefekt || bremse.hebel>-30) && ((stopp)) && fahrkorb.yPos>topfloor-SKO-SKO+3){if(auf){umrichterdaten[0]-=0.01;} if(umrichterdaten[0]===0){auf=false;ab=true;} if(ab){umrichterdaten[0]+=0.01;} }
   
  if(aktiverSI && passiverSI){
  if(schnell && umrichterdaten[0]<(umrichterdaten[1])){umrichterdaten[0]+=(umrichterdaten[4]/1000);if(umrichterdaten[0]>(umrichterdaten[1])){umrichterdaten[0]=(umrichterdaten[1]);}}
  if(langsam && umrichterdaten[0]>(umrichterdaten[2])){umrichterdaten[0]-=(umrichterdaten[5]/1000);if(umrichterdaten[0]<(umrichterdaten[2])){umrichterdaten[0]=(umrichterdaten[2]);}}
  if(langsam && umrichterdaten[0]<(umrichterdaten[2])){umrichterdaten[0]+=(umrichterdaten[4]/1000);if(umrichterdaten[0]>(umrichterdaten[2])){umrichterdaten[0]=(umrichterdaten[2]);}}
  if(inspektionsgeschwindigkeit && umrichterdaten[0]<(umrichterdaten[3])){umrichterdaten[0]+=(umrichterdaten[4]/1000);if(umrichterdaten[0]>(umrichterdaten[3])){umrichterdaten[0]=(umrichterdaten[3]);}}
  if(inspektionsgeschwindigkeit && umrichterdaten[0]>(umrichterdaten[3])){umrichterdaten[0]-=(umrichterdaten[5]/1000);if(umrichterdaten[0]<(umrichterdaten[3])){umrichterdaten[0]=(umrichterdaten[3]);}}
 if(stopp && umrichterdaten[0]>0  && einfahrt){umrichterdaten[0]-=(umrichterdaten[6]/1000);if(umrichterdaten[0]<=0){umrichterdaten[0]=0;}}
  }
  
  if(umrichterdaten[0]===0){einfahrt=false;}//sicherheitsschaltung zurueck setzen
  
  if(bremse.hebel>-30){bremse.manuelleBremsenoeffnung=true;}                                                           //  \
  if(bremse.hebel<-30 && bremse.manuelleBremsenoeffnung){notstopp=true;}                                               //   -- manuelles bremse lueften und zuruecksetzten, wenn hebel losgelassen wird
  if(bremse.manuelleBremsenoeffnung && bremse.hebel<-30 && umrichterdaten===0){bremse.manuelleBremsenoeffnung=false;}  //  /
  
  
  
  if(umrichterdaten[0]>0 && !bremse.manuelleBremsenoeffnung && (!notstopp || (fangundgb.eingerastet && !fangundgb.ab))){bremse.oeffnen=true;}//
  //if(bremse.hebel>-3){bremse.oeffnen=true;}
  //if(!bremse.oeffnen && umrichterdaten[0]>0){umrichterdaten[0]-=0.01;}
  if(ab ){fahrkorb.yPos-=umrichterdaten[0];}
  if(auf && !fangundgb.eingerastet){fahrkorb.yPos+=umrichterdaten[0];}
  if(!GBkontakt && auf){umrichterdaten[0]=0;}
  
  
  //_________________________________Fahrkorb_ueberfaehrt_endschalter_und_springt___________________________________________
  if(fahrkorb.yPos>((etagenanzahl-1)*etagenhoehe)+SKU+SKU+topfloor){fahrkorb.yPos=fahrkorb.yPos-=3;}
  if(fahrkorb.yPos<topfloor-SKO-SKO){fahrkorb.yPos=fahrkorb.yPos+=3;umrichterdaten[0]=0;}
 
  
}
//___________________________________________________S_I_C_H_E_R_H_E_I_T_S_K_R_E_I_S_________________________________________________________________________________________

function sicherheitskreis(){
 
  this.sicherheitsschaltung=false;
  if(umrichterdaten[0]<0.31 && tuerzone && einfahrt){this.sicherheitsschaltung=true;}
  
  
  
  
  this.addierer=0;                           //                                 --
  for(f=0;f<etagenanzahl;f++){               //                                     \
  this.addierer=this.addierer+etagen[f].KTS;}//                                      --- zusammenzaehlen aller schachttuerkontakte und des kabinentuerkontaktes
  if((this.addierer===etagenanzahl && KTC)|| this.sicherheitsschaltung )  //        /
  {aktiverSI=true;}else{aktiverSI=false;}    //                                 --
  

  
  
  
  if(fahrkorb.yPos>((etagenanzahl-1)*etagenhoehe)+SKU+topfloor){endschalterUnten=false;}else{endschalterUnten=true;}//    endschalter unten
  if(fahrkorb.yPos<topfloor-SKO){endschalterOben=false;}else{endschalterOben=true;}                                 //    und oben ueberwachen
  
  for(f=0;f<fahrflasche.length;f++){if(fahrflasche[f].insp && fahrflasche[f].prio===3){endschalterUnten=true;endschalterOben=true;GBkontakt=true;}}//ueberbrueckung der endschalter und geschwindigkeitsbegrenzerkontakt mit der rueckholsteuerung
 
  
  
 
 this.inspektionsfahrtenSI=0;
 for(f=0;f<fahrflasche.length;f++) // ________________________________________auswertung,_ob_inspektionsfahrt_geschaltet_und_fahrtaste_gedrueckt_ist________________________________________________________
 {if(fahrflasche[f].nothalt && ((!fahrflasche[f].insp || (fahrflasche[f].insp &&((fahrflasche[f].auf && fahrflasche[f].zweiter) || (fahrflasche[f].ab && fahrflasche[f].zweiter)))))){this.inspektionsfahrtenSI++;}}
 
 inspektionAktiv=false;
 for(f=0;f<fahrflasche.length;f++)//______________________________________________ist einer der inspektionsschalter eingeschaltet, muss das auch die steuerung wissen
 {if(fahrflasche[f].insp){inspektionAktiv=true;}}
 
 for(f=0;f<fahrflasche.length;f++){if(fahrflasche[f].nothalt){this.inspektionsfahrtenSI++;}}//sind alle nothalteschalter frei?
 
 for(f=0;f<fahrflasche.length;f++)//_______________WENN_INSPEKTION AKTIV UND RUECKHOLEN AKTIV DANN GEBE INSPEKTION FREI UND BLOCKIERE RUECKHOLEN_________________________________________
 {if(fahrflasche[f].insp && fahrflasche[f].prio===2 && !fangundgb.eingerastet){for(g=0;g<fahrflasche.length;g++){if(fahrflasche[g].insp && fahrflasche[g].prio===3){this.inspektionsfahrtenSI++;}}}}
 
 if(this.inspektionsfahrtenSI===fahrflasche.length*2){inspektionsfahrtenSI=true;}else{inspektionsfahrtenSI=false;}//feststellen, das der Sicherheitskreis im Inspektionsschalterkreis zu ist.tueren beeinflussen!
 
 if(this.inspektionsfahrtenSI===fahrflasche.length*2 && endschalterUnten && endschalterOben && GBkontakt && spanngewicht) //______________zusammenzaehlen der sicherheitskreispunkte
 {passiverSI=true;}else{passiverSI=false;}
  
  
  if(!passiverSI){for(f=0;f<etagenanzahl;f++)//_________________________________________________________________________________pasiver sicherheitskreis OFF loescht alle rufe
  {aussenab[f]=false;aussenabBefehl[f]=false;innen[f]=false;innenBefehl[f]=false;aussenauf[f]=false;aussenaufBefehl[f]=false;}}
  
  
  if((!passiverSI || !aktiverSI) && umrichterdaten[0]!=0) {notstopp=true;}// loese notstopp aus --> in antriebssteuerung
  
  
}


//________________________________________________________________F_A_H_R_F_L_A_S_C_H_E___________________________________________________________________________________
//a und b sind die anfangsposition MITTE FAHRFLASCHE
//c gibt die rangfolge an. 4=nothalt ohne fahrtasten 3=rueckholung 2=inspektionsfahrt 1=grubensteuerung
//d=true bedeutet mit freigabetaste (fuer beide richtungen)
//

function Fahrflasche(a,b,c,d){
  this.xPos=a;
     this.yPos=b;
     this.prio=c;
     this.freigabe=d;
  this.radius=40;
  this.nothalt=true;//true bedeutet, nothalt ist NICHT grdrueckt
  this.nothaltTimer=millis()+500;
  this.nothaltDrehen=0;
  this.insp=false;//true bedeutet, inspektion ist aktiviert
  this.inspTimer=millis()+500;
  this.inspDrehen=0;
  this.auf=false;
  this.ab=false;
  this.zweiter=false;
  
   this.anzeigen=function()
   {
     stroke(0);strokeWeight(strichdicke*gg/4);
     if(this.prio<4){this.grossesTablo();}//____________________________normale_inspektionstablos
     if(this.prio===4){this.kleinesTablo();}//__________________________nur_nothalt______________
   };
     
     
    this.grossesTablo=function(){ 
     
  rectMode(CENTER);
  fill(240,240,30);
  
   push();
   translate(this.xPos*gg,this.yPos*gg);
  rect(0,0,76*gg,280*gg,20*gg);
  rotate(-90);
  textFont('Helvetica');textSize(20*gg);textAlign(CENTER,TOP);
  noStroke();fill(255);
  if(this.prio===3){text("Rückholsteuerung",0,-60*gg);}
  if(this.prio===2){text("Inspektionssteuerung",0,-60*gg);}
  if(this.prio===1){text("Grubensteuerung",0,-60*gg);}
  pop();
  
  
  //___________________________________________NOTHALT____________________________________________________________
  noStroke();
  fill(255,0,0);
  push();
  translate(this.xPos*gg,(this.yPos-110)*gg);//setze neuen nullpunkt der koordinaten innerhalb push() und pop()
  circle(0,0,this.radius*gg);
  if(dist(mausX,mausY,this.xPos*gg,(this.yPos-110)*gg)<this.radius/2*gg && this.nothaltTimer<millis()){this.nothalt=!this.nothalt;this.nothaltTimer=millis()+500;}
  fill(0,255,0);
  if(this.nothalt && this.nothaltDrehen>0){this.nothaltDrehen-=2;}
  if(!this.nothalt){fill(255,141,0);if(this.nothaltDrehen<30){this.nothaltDrehen+=2;}}
  rotate(this.nothaltDrehen);//jetzt werden nur die pfeile leicht gedreht
  triangle(0,0,-15*gg,-5*gg,-15*gg,5*gg);
  triangle(0,0,-5*gg,-15*gg,5*gg,-15*gg);
  triangle(0,0,15*gg,-5*gg,15*gg,5*gg);
  triangle(0,0,-5*gg,15*gg,5*gg,15*gg);
  
  pop();//alles wie vorher
  
  //__________________________________________UMSCHALTER____INSPEKTION________________________________
  
  push();
  translate(this.xPos*gg,(this.yPos-40)*gg);
  stroke(255,195,0);strokeWeight(strichdicke*gg);
  fill(0);
  circle(0,0,this.radius*gg);
  if(dist(mausX,mausY,this.xPos*gg,(this.yPos-40)*gg)<this.radius/2*gg && this.inspTimer<millis()){this.insp=!this.insp;this.inspTimer=millis()+500;}
  stroke(255);
  if(!this.insp && this.inspDrehen<0){this.inspDrehen+=4;}
  if(this.insp && this.inspDrehen>-90){this.inspDrehen-=4;}
  rotate(this.inspDrehen);
  line(0,0,15*gg,0);
  
  pop();
  
  //_____________________ZEICNE___INSPEKTIONSSYMBOLE_______________________
  stroke(0);strokeWeight(strichdicke/2*gg);
  line((this.xPos+28)*gg,(this.yPos-30)*gg,(this.xPos+28)*gg,(this.yPos-50)*gg);
  line((this.xPos+23)*gg,(this.yPos-50)*gg,(this.xPos+33)*gg,(this.yPos-50)*gg);
  line((this.xPos+23)*gg,(this.yPos-46)*gg,(this.xPos+33)*gg,(this.yPos-46)*gg);
  line((this.xPos)*gg,(this.yPos-64)*gg,(this.xPos)*gg,(this.yPos-84)*gg);
  line((this.xPos-5)*gg,(this.yPos-84)*gg,(this.xPos+5)*gg,(this.yPos-84)*gg);
  line((this.xPos-5)*gg,(this.yPos-80)*gg,(this.xPos+5)*gg,(this.yPos-80)*gg);
  stroke(255,0,0);
  line((this.xPos+23)*gg,(this.yPos-30)*gg,(this.xPos+33)*gg,(this.yPos-53)*gg);
  
 
  //___________________________________________TASTE___AB_____________________________________________________
  stroke(255,195,0);strokeWeight(strichdicke*gg);
   push();
   translate(this.xPos*gg,(this.yPos+10)*gg);
  fill(255);
  circle(0,0,this.radius*gg);
  if(dist(mausX,mausY,this.xPos*gg,(this.yPos+10)*gg)<this.radius/2*gg){this.ab=true;}else{this.ab=false;}
  if(this.ab){scale(0.7);}
  circle(0,0,this.radius*gg);
  stroke(0);
  line(0,10*gg,0,-10*gg);
  line(0,-10*gg,-10*gg,-5*gg);
  line(0,-10*gg,10*gg,-5*gg);
  pop();
  
  //__________________________________________TASTE___AUF_______________________________________________________
  fill(0);stroke(255,195,0);strokeWeight(strichdicke*gg);
  push();
  translate(this.xPos*gg,(this.yPos+60)*gg);
  circle(0,0,this.radius*gg);
  if(dist(mausX,mausY,this.xPos*gg,(this.yPos+60)*gg)<this.radius/2*gg){this.auf=true;}else{this.auf=false;}
  if(this.auf){scale(0.7);}
  circle(0,0,this.radius*gg);
  stroke(255);
  line(0,10*gg,0,-10);
  line(0,10*gg,-10*gg,5*gg);
  line(0,10*gg,10*gg,5*gg);
  
  pop();
  
  if(this.freigabe){
  
  //_____________________________TASTE___FREIGABE_________________________________________________________
  fill(0,0,255);stroke(255,195,0);strokeWeight(strichdicke*gg);
  push();
  translate(this.xPos*gg,(this.yPos+110)*gg);
  circle(0,0,this.radius*gg);
  if(dist(mausX,mausY,this.xPos*gg,(this.yPos+110)*gg)<this.radius/2*gg || this.ab || this.auf){this.zweiter=true;}else{this.zweiter=false;}
  if(this.zweiter){scale(0.7);}
  circle(0,0,this.radius*gg);
  stroke(255);
  line(0,10*gg,0,-10);
  line(0,10*gg,-10*gg,5*gg);
  line(0,10*gg,10*gg,5*gg);
  line(0,-10*gg,-10*gg,-5*gg);
  line(0,-10*gg,10*gg,-5*gg);
  pop();}
  if(!this.freigabe){this.zweiter=true;}
   };
   
   
   
 this.kleinesTablo=function(){ //_______________________________NUR_NOTHALTSCHALTER____________________________
   
  rectMode(CENTER);
  fill(240,240,30);
  push();
  translate(this.xPos*gg,this.yPos*gg);
  rect(0,0,70*gg,70*gg,20*gg);
  rotate(-90);
  textFont('Helvetica');textSize(20*gg);textAlign(CENTER,TOP);
  noStroke();fill(255);
  text("Nothalt",0,-60*gg);
  pop();
  
  fill(255,0,0);
  noStroke();
  push();
  translate(this.xPos*gg,(this.yPos)*gg);//setze neuen nullpunkt der koordinaten innerhalb push() und pop()
  circle(0,0,this.radius*gg);
  if(dist(mausX,mausY,this.xPos*gg,(this.yPos)*gg)<this.radius/2*gg && this.nothaltTimer<millis()){this.nothalt=!this.nothalt;this.nothaltTimer=millis()+500;}
  fill(0,255,0);
  if(this.nothalt && this.nothaltDrehen>0){this.nothaltDrehen-=2;}
  if(!this.nothalt){fill(255,141,0);if(this.nothaltDrehen<30){this.nothaltDrehen+=2;}}
  rotate(this.nothaltDrehen);//jetzt werden nur die pfeile leicht gedreht
  triangle(0,0,-15*gg,-5*gg,-15*gg,5*gg);
  triangle(0,0,-5*gg,-15*gg,5*gg,-15*gg);
  triangle(0,0,15*gg,-5*gg,15*gg,5*gg);
  triangle(0,0,-5*gg,15*gg,5*gg,15*gg);
  
  pop();//alles wie vorher
   
 };
  
}




  
  
