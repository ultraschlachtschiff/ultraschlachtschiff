function windowResized() {
  fensterbreite=windowWidth;
 fensterhoehe=windowHeight;
  resizeCanvas(fensterbreite,fensterhoehe);
  gg=map(1,0,1920,0,windowWidth);
}

 function touchStarted() {
    mausX=mouseX;
    mausY=mouseY;





 }

function touchEnded()
{
 mausX=0;
    mausY=0; 
  for(f=0;f<individuell.length;f++){individuell[f].gedrueckt=false;}//boolean "gedrueckt" in den steuergeraeten zuruecksetzen
  
}


function touchMoved() {
  
  
  
}
