
//programmiert fuer fenstergroesse 1920 x 937. die variable "gg" (globale groesse) passt diese daten 
//beim zeichnen auf die tatsaechliche fenstergroesse an. es wird immer mit den original daten gerechnet.
//der simulator faehrt gerechnet in die falsche richtung. wenn ab true ist, faehrt der fahrkorb auf dem bildschirm auf.
//das haengt mit den koordinatensystem zusammen, welches die y-achse von oben nach unten zaehlt. also aufpassen bei der visualisierung ;)

//freeware fuer alle. keine beschraenkungen. frei und individuell veraenderbar. diese software ist entstanden in der freizeit und gehoert der welt.
//entwicklung: oliver bauer / germany / bauero@web.de
//es wird keine haftung übernommen, da es sich um experimentellen code handelt
//lizens für diesen Code sowie die bibliothek p5.min.js :    https://creativecommons.org/licenses/by-nc-sa/4.0/deed.de
//der code wurde mit der bibliothek p5.min.js erstellt
//p5.js is currently led by Qianqian Ye and evelyn masso and was created by Lauren Lee McCarthy. 
//p5.js is developed by a community of collaborators, with support from the Processing Foundation 
//and NYU ITP. Identity and graphic design by Jerel Johnson. © Info.
//weitere informationen zum copyright sowie zur sprache selbst findest du hier:    https://p5js.org/



let anfangsmenu;//beim neustart aufrufen

let fensterbreite;
let fensterhoehe;
let hintergrund;
let etagenzahl;//max. 6 etagen
let etagenhoehe;//600 pixel teilen sich auf die anzahl der etagen 
let abstandSchacht;//rechter abstand zum fensterende
let topfloor;//abstand oberste etage zum oberen fensterrand
let steuerungsart;    //art der steuerung 1= sammeln abwaerts 2=sammeln auf/ab  - fuer initialisierung eines etagenobjektes
let gg;//anpassen aller groessen an fenstergroesse
let f;let g;//globale variablen fuer schleifen
let fahrkorb;
let gegengewicht;
let motor;
let innentablo;
let fangundgb;
let bremse;
let schachtlichtfeld=[];//feld fuer hintergrundlicht
let individuell=[];//feld fuer individuelle objekte
let fahrflasche=[];//feld fuer unterschiedliche fahrflaschen
let etagen=[];//feld fuer die einzelnen etagen
let aussenauf=[];//feld fuer aussenrufe auf
let aussenab=[];//feld fuer aussenrufe ab
let innen=[];//feld fuer innenkomandos
let aussenaufBefehl=[];
let aussenabBefehl=[];
let innenBefehl=[];
let standort=[];//feld fuer den kabinenstandort
let etagenname=[];//feld fuer die benennung der etagen
let standortDez;//dezimalwert fuer standort
let umrichterdaten=[];//feld füer die umrichterdaten
let beschleunigung;//beschleunigungswert
let verzoegerung;//verzoegerungswert
let geschwVS;//definition schnelle geschwindigkeit
let geschwVL;//definition der langsamen geschwindigkeit
let geschwInsp;//definition inspektionsgeschwindigkeit
let geschwAktuell;//aktuelle fahrkorbgeschwindigkeit
let verzoegerungsweg;//strecke fuer die verzoegerung
let einfahrt;//signal fuer die sicherheitsschaltung,scharf zu werden
let schnell;//befehl schnelle geschwindigkeit
let langsam;//befehl langsame geschwindigkeit
let inspektionsgeschwindigkeit;//befehl inspektionsgeschwindigkeit setzen
let bremseOffen;//true,wenn bremse manuell geoeffnet
let bremseDefekt;//defekt hebt die bremswirkung auf, kabine trudelt

let notstopp;//notstopp geht auf bremsendynamik ein
let notstoppverzoegerung;//verzoegerungswert bei einem notstopp ueber die bremse
let ausloesegeschwindigkeitFang;//schwellenwert fuer das einrasten des gb
let auf;//befehl fahrt auf
let ab;//befehl fahrt ab
let stopp;//befehl anlage auf 0 verzoegern
let tuerzone;//bereich der ueberbrueckten tuerkontakte
let distanz;//beinhaltet die distanz der aktuellen kabinenposition zur naechsten buendigposition
let addierer;//zaehlvariable fuer die kontrolle, ob noch rufe in der aktuellen fahrtrichtung anstehen
let mausX;
let mausY;
let strichdicke;//staerke der striche
let schriftgroesse;
let dotmatrix;//für anzeigen

            
            //sicherheitskreis
let KTC;//tuerkontakt kabinentuer
//let nothaltRueck;
//let umschalterRueck;
//let nothaltDach;
//let umschalterDach;
//let nothaltGrube;
//let umschalterGrube;
//let tasteAuf;
//let tasteAb;
//let tasteZweiter;
let endschalterUnten;
let SKU;
let endschalterOben;
let SKO;
let GBkontakt;//kontakt am geschwindigkeitsbegrenzer
let spanngewicht;//kontakt am begrenzerspanngewicht
let aktiverSI;//aktiver sicherheitskreis komplett geschlossen
let passiverSI;//passiver sicherheitskreis
let inspektionsfahrtenSI;//nothalte der inspektionssteuerungen sowie umschalter
let inspektionAktiv;//wird true, wenn ein schalter auf inspektion steht


//befehle
let doorOpen;//kabinentuer oeffnen
let doorOpened;//endschalter tuer auf
let doorClose;// kabinentuer schliessen
let doorClosend;//endschalter tuer zu
let tuerenBleibenZu;//tueren sperren
let aussenEin;//solange TRUE, koennen aussenrufe gegeben werden
let fruehOeffnendeTueren;//funktion aus oder einschalten
let schachtlicht;//aktivierung vom Schachtlicht
let lichtstaerke;//helligkeit


let timer;

function preload(){
  dotmatrix=loadFont('data/1979_dot_matrix.ttf');//dot-matrix schrift wird definiert
}




function setup() {
  
  anfangsmenu=true;
  
  fensterbreite=windowWidth;
  fensterhoehe=windowHeight;
  createCanvas (fensterbreite,fensterhoehe);
  gg=map(1,0,1920,0,windowWidth);
  f=0;g=0;
  hintergrund=0;
  etagenanzahl=4;
  etagenhoehe=550/etagenanzahl;
  topfloor=250;
  standortDez=0;
  steuerungsart=1;
  mausX=mouseX;
  mausY=mouseY;
  strichdicke=5;
  Schriftgroesse=40;
  umrichterdaten[0]=0;//aktuelle geschwindigkeit
  umrichterdaten[1]=1.6;//V_max
  umrichterdaten[2]=0.3;//V_langsam
  umrichterdaten[3]=0.3;//V_inspektion
  umrichterdaten[4]=30;//beschleunigungswert
  umrichterdaten[5]=30;//verzoegerungswert
  umrichterdaten[6]=20;//verzoegerungswert schlussanhalten
  sturzgeschwindigkeit=0.01;
  einfahrt=false;
 
 
  verzoegerungsweg=round(etagenhoehe/2);

 
  schnell=false;
  langsam=false;
  inspektionsgeschwindigkeit=false;
  bremseOffen=false;
  bremseDefekt=false;
  notstopp=false;
  notstoppverzoegerung=50;
  ausloesegeschwindigkeitFang=umrichterdaten[1]*1.1;
  auf=false;
  ab=false;
  stopp=true;
  tuerzone=false;
  //addierer=0;
  for(f=0;f<etagenanzahl;f++)
 {
   etagen[f]=new Etage(1500,etagenhoehe,1,f);  
   aussenab[f]=false;
   aussenauf[f]=false;
   standort[f]=false;
   innen[f]=false;
   aussenaufBefehl[f]=false;
   aussenabBefehl[f]=false;
   innenBefehl[f]=false;
   etagenname[f]=map(f,0,etagenanzahl-2,etagenanzahl-2,0);
 }
 
   etagen[2]=new Etage(1500,etagenhoehe,2,2);
  fahrkorb=new Fahrkorb(1500+(etagenhoehe/10),etagenhoehe,standortDez);
  gegengewicht=new Gegengewicht(1500+(etagenhoehe/10)+(etagenhoehe/2)+110,standortDez);
  motor=new Motor(1500+(etagenhoehe/10)+(etagenhoehe/2)+60,100);
  innentablo=new Innentablo(1200,500,etagenanzahl);
  fangundgb=new FangundGB(1460,112);
  bremse=new Bremse(1150,200);
  
  fahrflasche[0]=new Fahrflasche(900,167,3,false);
  fahrflasche[1]=new Fahrflasche(1150,675,2,true);
  fahrflasche[2]=new Fahrflasche(1850,700,1,true);
  fahrflasche[3]=new Fahrflasche(1760,595,4,true);
  
  individuell[0]=new Mainboard(100,25);
  individuell[1]=new Reglung(450,25);
    
   KTC=true;
   endschalterUnten=true;
   SKU=25;
   endschalterOben=true;
   SKO=25;
   GBkontakt=true;
   spanngewicht=true;
   GBkontakt=true;
   aktiverSI=true;
   passiverSI=true;
   inspektionsfahrtenSI=true;
   inspektionAktiv=false;
   
   
   doorOpen=false;
   doorClose=true;
   tuerenBleibenZu=false;
   aussenEin=true;
   fruehOeffnendeTueren=false;
   schachtlicht=false;
   lichtstaerke=0;
   
   
   
   timer=millis();
   angleMode(DEGREES);
   
}


function draw() {
background(hintergrund);

if(anfangsmenu){Anfangsmenu();}
    
   sicherheitskreis();
   fahren();
   regelung();
   for(f=0;f<etagen.length;f++){Schachtlicht(etagen[f].xPos,etagen[f].yPos,etagen[f].etagenhoehe);}
   motor.anzeigen();
   fangundgb.anzeigen();
   bremse.anzeigen();
   
   fahrkorb.anzeigen();
   gegengewicht.anzeigen();
   innentablo.anzeigen();
   for(f=0;f<fahrflasche.length;f++){fahrflasche[f].anzeigen();}
   for(f=0;f<etagen.length;f++){etagen[f].anzeigen();}
   for(f=0;f<individuell.length;f++){individuell[f].anzeigen();}

 
  
  
  
  
  
  
  
  
  
  fill(255);noStroke();
  textFont('Helvetica');textSize(12*gg);textAlign(LEFT);
  text("Datum:27.12.21",0,10);
  text("Version 10.0",0,40);
  textSize(40*gg);
  text("Early Access ;)",25*gg,600*gg);
  text("Bitte melde Bugs!",25*gg,650*gg);
  text("Bitte mache Verbesserungsvorschläge!",25*gg,700*gg);
  
  text("bauero@web.de",25*gg,750*gg);
  //text(bremse.ausfallzaehler+"   "+bremseDefekt+"   "+notstopp+"   "+einfahrt,25,700);
  textSize(24*gg);
  text("Klicke auf die Bremsbeläge - es gibt 4 Abnutzungsstufen.",25*gg,350*gg);
  text("Klicke auf die Bremsenfedern - es gibt eine gute und eine weniger gute Einstellung.",25*gg,380*gg);
  text("Klicke auf den Geschwindigkeitsbegrenzer - oder erhöhe die Maximalgeschwindigkeit.",25*gg,410*gg);
  text("Klicke auf die Schachttüren, wenn kein Fahrkorb dahinter steht.",25*gg,440*gg);
  text("Verändere Parameter, um die Auswirkung auf die Anhaltegenauigkeit zu simulieren.",25*gg,470*gg);
  text("Teste die Inspektionstablos. Klicke auf die Seilspannrolle des GB-Seils",25*gg,500*gg);
  text("Probiere den Bremslüfthebel aus",25*gg,530*gg);
  text("Du willst neu starten? Aktualisiere Deinen Browser ;)",25*gg,560*gg);
  //text(inspektionsfahrtenSI,25,750);
 //text(fensterbreite,25,450);
 //text(fensterhoehe,25,480);
 //text(mouseX,25,510); 
 //text(mouseY,25,540); 
 //text(gg,25,570);
 //for(f=0;f<etagenanzahl;f++){
    
 //text(innen[f]+"   "+innenBefehl[f]+"  "+aussenab[f]+"  "+aussenabBefehl[f]+"   "+aussenauf[f]+"   "+aussenaufBefehl[f],25,600+(f*30));
 //  }
 //  text(fahren.inspektion,25,710);
   //text(ab+"   "+auf+"   "+schnell+"   "+langsam+"   "+stopp,25,840);
 //  text(aktiverSI+"   "+passiverSI,25,770);
 //  text(tuerzone,25,800);
 
}
