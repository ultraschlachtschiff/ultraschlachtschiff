//a=xPos motor
//b=yPos motor

function Motor(a,b){
  
  this.xPos=a;
  this.yPos=b;
  this.strichdicke=5;
  this.handradmarkierung=65;
  this.grad=0;
  
  
  this.anzeigen=function()
   {
     if(auf){this.handradmarkierung+=(umrichterdaten[0]*10); if(this.handradmarkierung > 180){this.handradmarkierung=0;}this.grad-=(umrichterdaten[0]*0.80);}
     if(ab){this.handradmarkierung-=(umrichterdaten[0]*10);if(this.handradmarkierung<-180){this.handradmarkierung=70;}this.grad+=(umrichterdaten[0]*0.80);}
     
     
     
     
     //this.grad=-fahrkorb.yPos;
     push();
     rectMode(CORNERS);
     translate((this.xPos-200)*gg,(this.yPos-35)*gg);
      stroke(0);
      strokeWeight(strichdicke*gg/4);
      fill('#E4E3EA');
      rect(-50*gg,100*gg,300*gg,80*gg);//____________________________betonsockel
      fill('#2310A2');
      rect(10,80*gg,90*gg,60*gg);//______________________________maschienenfuss
      fill(200);
     rect(100*gg,30*gg,110*gg,40*gg);//_______________________linke achse bremstrommel
     rect(110*gg,0*gg,130*gg,70*gg);//________________________bremstrommel
     rect(130*gg,30*gg,140*gg,40*gg);//_________________________rechte achse bremstrommel
     stroke(0);
     fill(60,140,180);
     rect(0,0,100*gg,70*gg);//__________________________________motorgehaeuse
     quad(0,0,-20*gg,20*gg,-20*gg,50*gg,0,70*gg);//_____________motorabschluss
     fill(255,255,0);
     rect(-40*gg,0,-30*gg,70*gg,5*gg);//________________________handrad
     strokeWeight(strichdicke*gg);
     if(this.handradmarkierung>0 && this.handradmarkierung<70)
     {circle(-35*gg,this.handradmarkierung*gg,2*gg);}//_____markierung am handrad
     
     strokeWeight(strichdicke*gg/4);
     rect(-30*gg,30*gg,-20*gg,40*gg);//_________________________achse handrad
     strokeWeight(this.strichdicke*gg);
     stroke(10,10,255);
     for(f=0;f<6;f++){line(10*gg,((f*10)+10)*gg,90*gg,((f*10)+10)*gg);}//______kuehlrippen
     stroke(0);
     strokeWeight(strichdicke*gg/4);
     fill(10,100,140);
     rect(140*gg,-10*gg,240*gg,80*gg);//____________________________getriebegehaeuse
     strokeWeight(this.strichdicke*gg);
     stroke(10,14,200);
     for(f=0;f<8;f++){line(150*gg,f*10*gg,230*gg,f*10*gg);}//_________kuehlrippen getriebe
     fill(0,95,30);strokeWeight(strichdicke*gg/4);
     rect(125*gg,70*gg,140*gg,80*gg);//_____________________________achse bremsarm
     circle(120*gg,-20*gg,30*gg);//___________________________________bremsmagnet
     fill(175,132,12);rect(100*gg,-25*gg,105*gg,-15*gg);//____________buchse luefthebel
    stroke(0);fill(0,180,80);
     rect(115*gg,-30*gg,125*gg,80*gg);//______________________________bremsarm
     pop();
     strokeWeight(strichdicke/4*gg);
    stroke(0);
    fill(220);
   
    rectMode(CORNERS);
    rect((this.xPos-62)*gg,(this.yPos-25)*gg,(fahrkorb.xPos+3+(etagenhoehe/2))*gg,fahrkorb.yPos*gg);//_______fahrkorbseil
    rect((gegengewicht.xPos+(7))*gg,gegengewicht.yPos*gg,(this.xPos+62)*gg,(this.yPos-25)*gg);//____________gegengewichtsseil
     //strokeWeight(strichdicke*1*gg);
    stroke(0);
    for(f=0;f<75;f++){
    if(gegengewicht.yPos-(10*f)>this.yPos){line((gegengewicht.xPos+(7))*gg,(gegengewicht.yPos-(10*f))*gg,(gegengewicht.xPos+(13))*gg,(gegengewicht.yPos-(10*f)-10)*gg);}}
     for(f=0;f<75;f++){
    if(fahrkorb.yPos-(10*f)+10>this.yPos){line((fahrkorb.xPos-3+(etagenhoehe/2))*gg,(fahrkorb.yPos-(10*f))*gg,(fahrkorb.xPos+3+(etagenhoehe/2))*gg,(fahrkorb.yPos+10-(10*f))*gg);}}
    
    
     push();//_________________________________________________________ab hier treibscheibe
     translate((this.xPos)*gg,(this.yPos-30)*gg);
     rectMode(CENTER);
     rotate(this.grad);
     stroke(255,255,0);strokeWeight(this.strichdicke*3*gg);noFill();
     circle(0,0,120*gg);
     stroke(0);strokeWeight(strichdicke*gg/4);
     circle(0,0,135*gg); circle(0,0,105*gg);
     fill(255,255,0);
     rect(0,0,105*gg,15*gg);
     rect(0,0,15*gg,105*gg);
     circle(0,0,25*gg);
     
    
     pop();
   };
  
}
//____________________________________________________________G_E_S_C_H_W_I_N_D_I_G_K_E_I_T_S_B_E_G_R_E_N_Z_E_R___U_N_D___S_P_A_N_N_G_E_W_I_C_H_T_____________________________
  function FangundGB(a,b){
  this.xPos=a;
  this.yPos=b;
  this.durchmesser=50;
  this.grad=-fahrkorb.yPos*2;
  this.gradVorher=this.grad;
  this.rollenposition=this.yPos-(this.durchmesser/2);
  this.ausloesung=ausloesegeschwindigkeitFang;
  this.eingerastet=false; //gb eingerastet?
  this.auf=false;//eingerasteb aufwaerts (ACHTUNG! BERECHNET AUF! )
  this.ab=false;//eingerastet abwaerts
 
  this.timer=millis();//universeller timer
  this.extramass=70;//position der spanngewichtsrolle. es koennen 4 laengen simuliert werden, die letzte loesst kontakt aus
  
  
  this.anzeigen=function()
   {
   this.grad=fahrkorb.yPos*4;
   
   stroke(0);//__________________________________________________________seil_und_kupplung_______________________________________________________
   fill(220);
     strokeWeight(strichdicke/4*gg);
     rect((this.xPos-(this.durchmesser/2)-2)*gg,this.yPos*gg,(this.xPos-(this.durchmesser/2)+2)*gg,(topfloor+(etagenanzahl*etagenhoehe)+this.extramass)*gg);//__________________linkes seil
     rect((this.xPos+(this.durchmesser/2)-2)*gg,this.yPos*gg,(this.xPos+(this.durchmesser/2)+2)*gg,(topfloor+(etagenanzahl*etagenhoehe)+this.extramass)*gg);//__________________rechtes seil
     fill(150);
     
     
     for(f=-65;f<65;f++){
     if((this.yPos+(f*10)+fahrkorb.yPos)>this.yPos && (this.yPos+(f*10)-10+fahrkorb.yPos)<(topfloor+(etagenanzahl*etagenhoehe)+70))
     {line((this.xPos+(this.durchmesser/2)-2)*gg,(this.yPos+(f*10)+fahrkorb.yPos)*gg,(this.xPos+(this.durchmesser/2)+2)*gg,(this.yPos+(f*10)-10+fahrkorb.yPos)*gg);}
     }
      for(f=-65;f<65;f++){
     if((this.yPos+(f*10)+gegengewicht.yPos)>this.yPos && (this.yPos+(f*10)-10+gegengewicht.yPos)<(topfloor+(etagenanzahl*etagenhoehe)+70))
     {line((this.xPos-(this.durchmesser/2)-2)*gg,(this.yPos+(f*10)+gegengewicht.yPos)*gg,(this.xPos-(this.durchmesser/2)+2)*gg,(this.yPos+(f*10)-10+gegengewicht.yPos)*gg);}
     }
     
     rect((this.xPos+(this.durchmesser/2))*gg,(fahrkorb.yPos+fahrkorb.fahrkorbhoehe-5)*gg,(fahrkorb.xPos)*gg,(fahrkorb.yPos+fahrkorb.fahrkorbhoehe+5)*gg);//________seilkupplung
     rect((this.xPos+(this.durchmesser/2)+5)*gg,(fahrkorb.yPos+fahrkorb.fahrkorbhoehe+20)*gg,(this.xPos+(this.durchmesser/2)-5)*gg,(fahrkorb.yPos+fahrkorb.fahrkorbhoehe-20)*gg);
     

      if(dist(mausX,mausY,this.xPos*gg,this.yPos*gg)<this.durchmesser*gg/2){this.eingerastet=true;if(ab){this.ab=true;}if(auf){this.auf=true;}}//________klicken am GB loest fang aus
      if(this.auf || this.ab){this.grad=this.gradVorher;}

     push();//__________________________________________________________gb_reibscheibe__________________________________
     translate(this.xPos*gg,this.yPos*gg);
    
     fill(255,255,0);
     rotate(this.grad);
     stroke(0);
     strokeWeight(strichdicke*gg/4);
     circle(0,0,this.durchmesser*gg*1.2);
     rectMode(CENTER);
     strokeWeight(strichdicke*gg);
     stroke(255,255,0);
     fill(200,200,0);
     strokeJoin(ROUND);
     rect(0,0,this.durchmesser*gg,this.durchmesser*gg,20*gg);
     stroke(135);
     strokeWeight(strichdicke/2*gg);
           beginShape();
   noFill();stroke('#463939');
   vertex(-15*gg,-10*gg);
   bezierVertex(-10*gg,-20*gg,10*gg,-20*gg,15*gg,-10*gg);
   endShape();
     line(15*gg,-10*gg,10*gg,-20*gg);
     line(15*gg,-10*gg,5*gg,-13*gg);
     pop();
     
     push();//___________________________________________________begenzerspanngewichtrolle___________________________________
     stroke(255,255,0);
     
     fill(200,200,0);
     if(dist(mausX,mausY,this.xPos*gg,(topfloor+(etagenanzahl*etagenhoehe)+this.extramass)*gg)<15*gg && this.timer<millis() ){this.extramass+=5;this.timer=millis()+1000;}
     if(this.extramass>85){this.extramass=70;}
     translate(this.xPos*gg,(topfloor+(etagenanzahl*etagenhoehe)+this.extramass)*gg);
     
     
     rotate(fahrkorb.yPos*4);
     circle(0,0,this.durchmesser*gg);
     stroke(135);
     strokeWeight(strichdicke/2*gg);
     line(0,this.durchmesser/3*gg,this.durchmesser/3*gg,this.durchmesser/4*gg);
     noFill();stroke(0);strokeWeight(strichdicke*gg/4);
     circle(0,0,this.durchmesser*gg*1.1);
     pop();
    
     
     noStroke();//____________________________________________gehaeuse_und_wippe_______________________________________
     fill('#3950BC');
     rectMode(CENTER);
     stroke(0);strokeWeight(strichdicke*gg/4);
     triangle((this.xPos)*gg,this.yPos*gg,(this.xPos+5-(this.durchmesser*0.5))*gg,(this.yPos+(this.durchmesser/1.5))*gg,(this.xPos-5+(this.durchmesser*0.5))*gg,(this.yPos+(this.durchmesser/1.5))*gg);
     rect(this.xPos*gg,this.yPos*gg,(this.durchmesser/5)*gg,this.durchmesser*gg*1.3);
     fill(255);
     this.rollenposition=(-cos(this.grad*4)*2)+this.yPos-(this.durchmesser/2);
     this.hakenposition=(cos(this.grad*4)*2)+this.yPos-(this.durchmesser/2);
     
     if((umrichterdaten[0]>this.ausloesung ) || this.eingerastet) //___________________________________________________wippe rastet ein_____________________________________
     {if(auf && !this.ab){this.auf=true;}if(ab && !this.auf){this.ab=true;}this.hakenposition=this.yPos-(this.durchmesser/2)+5;this.rollenposition=this.yPos-(this.durchmesser/2)-5;this.eingerastet=true;GBkontakt=false;}
     
     
     circle((this.xPos-(this.durchmesser/2.5))*gg,this.rollenposition*gg,this.durchmesser/4*gg);
     stroke(0,0,255);strokeWeight(strichdicke*gg);
     line((this.xPos-(this.durchmesser/2.5))*gg,this.rollenposition*gg,(this.xPos+(this.durchmesser/2.5))*gg,this.hakenposition*gg);
     line((this.xPos+(this.durchmesser/2.5))*gg,this.hakenposition*gg,(this.xPos+(this.durchmesser/2.5))*gg,(this.hakenposition+(this.durchmesser/10))*gg);
     
     stroke(0);//_________________________________________________spanngewicht____________________________________________
     strokeWeight(strichdicke*gg/4);
     fill(0,100,255);
     push();
     translate((this.xPos+(this.durchmesser))*gg,(topfloor+(etagenanzahl*etagenhoehe)+70)*gg);
     rotate(70-this.extramass);
     rect(-150*gg,0,this.durchmesser*gg,this.durchmesser*gg,10*gg);
     strokeWeight(strichdicke*gg);stroke(40,10,240);
     line(0,0,-150*gg,0);
     pop();
     
     
     //__________________________________________________________spanngewichtskontakt__________________________________________
     push();
     fill(50,145,245);
     translate((this.xPos-(3*this.durchmesser))*gg,(topfloor+(etagenanzahl*etagenhoehe)+100)*gg);
     rect(0,0,20*gg,40*gg,5*gg);
     strokeWeight(strichdicke*gg/2);stroke(100);
     rotate(((70-this.extramass)*3)*-1);
     line(0,0,40*gg,0);
     if(this.extramass===85){spanngewicht=false;}else{spanngewicht=true;}
     
     pop();
     
    
   };
  
  
  
  
}

//________________________________________________________________B_R_E_M_S_E___________________________________________________________________________________________

function Bremse(a,b){
  
  
 this.xPos=a;
 this.yPos=b;
 this.durchmesser=150;
 this.radius=25;
 this.grad=20;
 this.bremse=0;//winkel fuer die bremsarmbewegung
 this.oeffnen=false; 
 this.manuelleBremsenoeffnung=false;
 this.schleier=300; 
 this.schleierHebel=300;//laesst bremsluefthebel verschwinden
 this.federn=true;//true=gut  false=schlecht 
 
 this.bremsluefthebel=false;
 this.hebel=-45;//winkel des bremsluefthebels
 //this.button=false;
 this.timer=millis();
 this.prellzeit=300;
 this.gut=90;//x-position des stellblozens
 this.schlecht=100;
 this.xBolzen=this.schlecht;
 this.belagSchlecht=false;
 this.belag=0;
 this.ausfallzaehler=0;//addiert die fahrten mit abgenutztem belag
 this.rot=40;//farbe der trommeloberflaeche
 this.gruen=40;
 this.blau=40;
 this.aktiv=false;
  
  
  
  
  
  
  
 this.anzeigen=function(){
   
   this.grad=motor.grad*20;
   //if(this.schleier<300){this.schleier+=10;}
  
   
   stroke(0,this.schleier);//___________________________________________getriebegehaeuse
   strokeWeight(strichdicke*gg/4);
   fill(10,100,140,this.schleier);
   rectMode(CENTER);
   rect(this.xPos*gg,(this.yPos-20)*gg,160*gg,210*gg,10*gg);
   
   fill(255,this.schleier);
   
   
  
  
   if(this.federn){notstoppverzoegerung=55-(this.belag*5);this.xBolzen=this.gut;}
   if(!this.federn){notstoppverzoegerung=40-(this.belag*5);this.xBolzen=this.schlecht;}
   if( this.belag===4 && this.oeffnen && !this.aktiv && this.rot>160){this.ausfallzaehler++;this.aktiv=true;}
   
  
   
   if(!this.oeffnen){this.aktiv=false;}
   
   if(this.ausfallzaehler===3 ){bremseDefekt=true;}//_____________________________________________feststellen, ob die bremse ausfaellt
   if(this.belag<4){this.ausfallzaehler=0;bremseDefekt=false;this.blau=0;}//__________________________________zuruecksetzen, wenn bremse "repariert" wurde
   
   
    fill(200,this.schleier);
    rect((this.xPos-35-(this.bremse*3.8)+(this.belag*3))*gg,(this.yPos-130)*gg,60*gg,20*gg);//_____magnetkolben
    rect((this.xPos+35+(this.bremse*3.8)-(this.belag*3))*gg,(this.yPos-130)*gg,60*gg,20*gg);//_____magnetkolben
    fill(0,95,30,this.schleier);strokeWeight(strichdicke*gg/4);//________________________bremsmagnet
    rect((this.xPos)*gg,(this.yPos-130)*gg,90*gg,60*gg,10*gg);
     //if(this.bremsluefthebel){this.bremseLueften();}
      this.bremseLueften();
    fill(175,132,12,this.schleier);circle((this.xPos)*gg,(this.yPos-130)*gg,this.radius*gg);//_______luefthebel-buchse
    //if(dist(mausX,mausY,(this.xPos)*gg,(this.yPos-130)*gg)<this.radius){this.bremsluefthebel=true;}
    
   
   
    
    
    fill(120,this.schleier);
    rect((this.xPos-this.xBolzen)*gg,(this.yPos-90)*gg,100*gg,10*gg);//bolzen
    rect((this.xPos+this.xBolzen)*gg,(this.yPos-90)*gg,100*gg,10*gg);
    
    fill(10,100,140,this.schleier);
    rect((this.xPos-60)*gg,(this.yPos-90)*gg,5*gg,30*gg);//befestigung
    rect((this.xPos+60)*gg,(this.yPos-90)*gg,5*gg,30*gg);
    fill(120,this.schleier);
    rect((this.xPos+65)*gg,(this.yPos-90)*gg,5*gg,15*gg);//muttern
    rect((this.xPos+55)*gg,(this.yPos-90)*gg,5*gg,15*gg);
    rect((this.xPos-65)*gg,(this.yPos-90)*gg,5*gg,15*gg);
    rect((this.xPos-55)*gg,(this.yPos-90)*gg,5*gg,15*gg);
    
    rect((this.xPos+this.xBolzen+50)*gg,(this.yPos-90)*gg,8*gg,35*gg);//federlager
    rect((this.xPos-this.xBolzen-50)*gg,(this.yPos-90)*gg,8*gg,35*gg);
    
    stroke(210,this.schleier);
    strokeWeight(strichdicke*gg);
   
    
    line((this.xPos-(this.xBolzen+50)+10-(this.bremse))*gg,(this.yPos-100)*gg,(this.xPos-(this.xBolzen+50)+15-(this.bremse))*gg,(this.yPos-80)*gg);//___________________federn links
    line(((this.xPos-110)*gg)-(this.bremse*(this.xBolzen/50)-(this.belag*1))-(((this.xBolzen+50)-120)/2)*gg,(this.yPos-100)*gg,((this.xPos-110)*gg)-(this.bremse*(this.xBolzen/50)-(this.belag*1))-(((this.xBolzen+50)-130)/2)*gg,(this.yPos-80)*gg);
    line((this.xPos-140+30-(this.bremse*3)+(this.belag*2.5))*gg,(this.yPos-100)*gg,(this.xPos-140+35-(this.bremse*3)+(this.belag*2.5))*gg,(this.yPos-80)*gg);
    
     line((this.xPos+(this.xBolzen+50)-10+(this.bremse))*gg,(this.yPos-100)*gg,(this.xPos+(this.xBolzen+50)-15+(this.bremse))*gg,(this.yPos-80)*gg);//___________________federn rechts
    line(((this.xPos+110)*gg)+(this.bremse*(this.xBolzen/50)-(this.belag*1))+(((this.xBolzen+50)-120)/2)*gg,(this.yPos-100)*gg,((this.xPos+110)*gg)+(this.bremse*(this.xBolzen/50)-(this.belag*1))+(((this.xBolzen+50)-130)/2)*gg,(this.yPos-80)*gg);
    line((this.xPos+140-30+(this.bremse*3)-(this.belag*2.5))*gg,(this.yPos-100)*gg,(this.xPos+140-35+(this.bremse*3)-(this.belag*2.5))*gg,(this.yPos-80)*gg);
   
   
     if((dist(mausX,mausY,((this.xPos+110)*gg)+(this.bremse*(this.xBolzen/50)-(this.belag*1))+(((this.xBolzen+50)-120)/2)*gg,(this.yPos-100)*gg)<this.radius //wurde eine der federn angefasst? zentrum ist die mittlere linie
     || dist(mausX,mausY,((this.xPos-110)*gg)-(this.bremse*(this.xBolzen/50)-(this.belag*1))-(((this.xBolzen+50)-120)/2)*gg,(this.yPos-100)*gg)<this.radius)
     && this.timer<millis()){this.timer=millis()+this.prellzeit;this.federn=!this.federn;}
    
 
   
   
   push();//________________________________________________bremstrommel
   translate(this.xPos*gg,this.yPos*gg);
   rotate(this.grad);
   if(this.belag===4 && umrichterdaten[0]>0.2 && this.rot<220){this.rot+=(umrichterdaten[0]);this.blau--;if(this.blau<0){this.blau=0;}}//____erhitzte oberflaeche
   if(this.belag===4 && this.rot>40 && umrichterdaten[0]===0 ){this.rot-=1;if(this.ausfallzaehler>1){this.blau+=2;}}//___________________________________________________ausgegluehte oberflaeche
   stroke(this.rot,this.gruen,this.blau,this.schleier);strokeWeight(strichdicke*2*gg);
   fill(200,this.schleier);
   circle(0,0,this.durchmesser*gg);//_______________________zeichne bremstrommel
   stroke(0,this.schleier);strokeWeight(strichdicke*gg/4);noFill();
   circle(0,0,(this.durchmesser+(strichdicke*gg*2))*gg);//__zeichne umriss bremstrommel
   fill(50,this.schleier);
   circle(-30*gg,-30*gg,this.durchmesser/8*gg);//kupplungsgummies
   circle(-30*gg,30*gg,this.durchmesser/8*gg);//       |
   circle(30*gg,-30*gg,this.durchmesser/8*gg);//       |
   circle(30*gg,30*gg,this.durchmesser/8*gg);//        V
   pop();
   
   
   
   
   if(((this.oeffnen)||(this.hebel>-30)) && this.bremse<(6-this.belag)){this.bremse++;}
 
   if((!this.oeffnen)&&(this.hebel<-30)){this.bremse=0;}
   
   push();//__________________________________________________________________________________bremsarm links__________________________
   rectMode(CENTER);
   translate((this.xPos-this.durchmesser/2)*gg,(this.yPos+this.durchmesser/2)*gg);
   rotate(-this.bremse+this.belag);
   stroke(0,this.schleier);strokeWeight(strichdicke*gg/4);fill(0,95,30,this.schleier);
   
  
   fill(120,this.schleier);
   
   rect(-15*gg,-205*gg,50*gg,10*gg);//______________________stellschraube
   rect(-40*gg,-205*gg,10*gg,15*gg);
   fill(0,180,80,this.schleier);
   rect(0,0,40*gg,10*gg);//___________________________kleiner achsenteil bremsarm
   rect(-15*gg,-110*gg,15*gg,230*gg);//_______________bremsarm
   circle(0,0,this.durchmesser/8*gg);//_______________achse
  

   if(dist(mausX,mausY,((this.xPos-this.durchmesser/2))*gg,(-80+this.yPos+this.durchmesser/2)*gg)<this.radius*2 && this.timer<millis()){this.timer=millis()+this.prellzeit;this.belag++;if(this.belag>4){this.belag=0;}}//bremsbelag angefasst?
   
   
   strokeWeight(strichdicke/4*gg);//__________bremsbelag
   beginShape();
   stroke(0,this.schleier);
   fill(75,58,26,this.schleier);
   curve(6*gg,-30*gg,(-5-(this.belag*0.6))*gg,-60*gg,(-5-(this.belag*0.8))*gg,-90*gg,(6-(this.belag*1.8))*gg,-120*gg);
   vertex(-15*gg,-120*gg);
   vertex(-15*gg,-30*gg);
   vertex(6*gg,-30*gg);
   
   
   endShape();
   
   pop();
   
   push();//__________________________________________________________________________________bremsarm rechts_____________________________
   rectMode(CENTER);
   translate((this.xPos+this.durchmesser/2)*gg,(this.yPos+this.durchmesser/2)*gg);
   rotate(this.bremse-this.belag);
   stroke(0,[this.schleier]);strokeWeight(strichdicke*gg/4);fill(0,95,30,this.schleier);
   
  
   fill(120,this.schleier);
   
   rect(15*gg,-205*gg,50*gg,10*gg);//______________________stellschraube
   rect(40*gg,-205*gg,10*gg,15*gg);
   fill(0,180,80,this.schleier);
   rect(0,0,40*gg,10*gg);//___________________________kleiner achsenteil bremsarm
   rect(15*gg,-110*gg,15*gg,230*gg);//_______________bremsarm
   circle(0,0,this.durchmesser/8*gg);//_______________achse
  
    if(dist(mausX,mausY,(this.xPos+this.durchmesser/2)*gg,(-80+this.yPos+this.durchmesser/2)*gg)<this.radius*2 && this.timer<millis()){this.timer=millis()+this.prellzeit;this.belag++;if(this.belag>4){this.belag=0;}}//bremsbelag angefasst?
   
   strokeWeight(strichdicke/4*gg);//__________bremsbelag
   beginShape();
   stroke(0,this.schleier);
   fill(75,58,26,this.schleier);
   curve(-6*gg,-30*gg,(5+(this.belag*0.6))*gg,-60*gg,(5+(this.belag*0.8))*gg,-90*gg,(-6+(this.belag*1.8))*gg,-120*gg);
   vertex(15*gg,-120*gg);
   vertex(15*gg,-30*gg);
   vertex(-6*gg,-30*gg);
   
   endShape();
   
   pop();
 
  
 };
  
  this.bremseLueften=function(){
    
     stroke(0,[this.schleierHebel]);strokeWeight(strichdicke*gg/4);fill(126,96,10,this.schleierHebel);
     //if(this.schleierHebel<300){this.schleierHebel+=10;}
     push();
     translate((this.xPos-10)*gg,(this.yPos-130)*gg);
     rotate(this.hebel);
     rectMode(CORNER);
     rect(0,0,80*gg,10*gg);
     //circle(80*gg,10*gg,this.radius*gg);
     if(this.schleierHebel>290 && dist(mausX,mausY,(this.xPos-5)*gg,(this.yPos-130)*gg)<this.radius && this.hebel<-20) {this.hebel++;}
     if(this.schleierHebel>290 && dist(mausX,mausY,(this.xPos-5)*gg,(this.yPos-130)*gg)>this.radius && this.hebel>-45) {this.hebel=-45;}
     if(this.hebel>-30){this.manuelleBremsenoeffnung=true;}
     pop();
    
    
    
    
  };
  
}
