
//a=xPos der Etage
//b=etagenhoehe, ermittelt aus der anzahl der etagen
//c=steuerungsart 1=ka 2=ks (3=pi)
//d=nummer der etage



function Etage(a,b,c,d) 
{
  this.xPos=a;
  this.etagenhoehe=b;
  this.yPos=((b*d)+topfloor);
  this.strichdicke=0.05*(this.etagenhoehe);
  this.xPosTuer=this.xPos+((this.etagenhoehe/10)*7);
  this.yPosTuer=this.yPos+(this.etagenhoehe/2);//10
  this.radius=this.etagenhoehe/4;
  this.etage=d;
  this.open=false;
  this.close=true;
  this.steuerungstyp=c;//1=ka 2=ks (3=pi) 4=sammeln richtung auf
  this.KTS=true;//zustand des schachttuerkontaktes
  this.schleier=180;//macht eine etage transparent. je kleiner der wert, je durchscheinender.
  this.timerManuell=millis()+500;//entprellzeit von 15cm-tuer-oeffnen zu komplett oeffnen (manuelles oeffnen)
  this.manuellGeoeffnet=false;
  
  
   this.anzeigen=function()
   {
     
     //this.schleier=200-(geschwAktuell*100);
     
     
     //_________________________________________________________________________schachttuer_mit_funktion_zum_oeffnen________________________________________________________________________________
   
     noStroke();
     rectMode(CENTER);
     fill(100);
     rect(this.xPosTuer*gg,this.yPosTuer*gg,((this.etagenhoehe/2)-(this.etagenhoehe/10))*gg,(this.etagenhoehe-(2*(this.etagenhoehe/10)))*gg);
     if((dist(mausX,mausY,(this.xPos+(this.etagenhoehe/10*7))*gg,this.yPosTuer*gg)<this.radius*gg/2) && this.close && this.timerManuell<millis()){this.xPosTuer-=this.etagenhoehe/10;this.close=false;this.timerManuell=millis()+500;this.manuellGeoeffnet=true;}
     if((dist(mausX,mausY,(this.xPos+(this.etagenhoehe/10*7))*gg,this.yPosTuer*gg)<this.radius*gg/2) && !this.close && !this.open && this.timerManuell<millis()){this.open=true;this.timerManuell=millis()+500;this.manuellGeoeffnet=true;}
     if((dist(mausX,mausY,(this.xPos+(this.etagenhoehe/10*7))*gg,this.yPosTuer*gg)<this.radius*gg/2) && this.open  && this.timerManuell<millis()){this.close=true;this.open=false;this.timerManuell=millis()+500;this.manuellGeoeffnet=false;}
     stroke(50);
     noFill();
     rect(this.xPos+((this.etagenhoehe/10)*7),this.yPos+(this.etagenhoehe/2),((this.etagenhoehe/2)-(this.etagenhoehe/10))*gg,(this.etagenhoehe-(2*(this.etagenhoehe/10)))*gg);
     
     
   
    
    
     rectMode(CORNERS);
     
     rect(this.xPos*gg,this.yPos*gg,(this.xPos+(this.etagenhoehe))*gg,(this.yPos+(this.etagenhoehe))*gg,10*gg); //weisser rahmen
     //_________________________________________________die_verkleidung_der_etage_________________________________________________________________________________________________________________
     fill(150,this.schleier);noStroke();
     rect(this.xPos*gg,this.yPos*gg,(this.xPos+(this.etagenhoehe/2))*gg,(this.yPos+(this.etagenhoehe))*gg);
     rect((this.xPos+(this.etagenhoehe/2))*gg,this.yPos*gg,(this.xPos+(this.etagenhoehe))*gg,(this.yPos+(this.etagenhoehe/10))*gg);
     rect((this.xPos+(this.etagenhoehe/2))*gg,(this.yPos+(9*(this.etagenhoehe/10)))*gg,(this.xPos+(this.etagenhoehe))*gg,(this.yPos+(this.etagenhoehe))*gg);
     rect((this.xPos+(9*(this.etagenhoehe/10)))*gg,(this.yPos+(this.etagenhoehe/10))*gg,(this.xPos+(this.etagenhoehe))*gg,(this.yPos+(this.etagenhoehe)-(this.etagenhoehe/10))*gg);
    
     
     //______________________________________________________schwarzer_rahmen____________________________________________________________________________________________________________________
     stroke(0);
     strokeWeight(this.strichdicke*gg);
     rectMode(CORNERS);
     noFill();
     rect(this.xPos*gg,this.yPos*gg,(this.xPos+(this.etagenhoehe))*gg,(this.yPos+(this.etagenhoehe))*gg,10*gg); 
    
     
     stroke(0);//tasten
     strokeWeight(this.strichdicke/2*gg);
     rectMode(CENTER);
     fill(255);
     //____________________________________________________RUFTASTE_________________AB____________________(VISUELL_AUF)___________WIRD_AUTOMATISCH_IN_ENDHALTESTELLE_AUFGERUFEN__________________
     if(this.etage===etagen.length-1 || (this.steuerungstyp===1 && this.etage===etagen.length-1) || this.steuerungstyp===4){//nur eine taste zeichnen
     if(dist(mausX,mausY,(this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2))*gg)<this.radius*gg/2){aussenab[this.etage]=true;} 
     if(aussenab[this.etage]){fill(0,255,0);}
     if(!aussenab[this.etage]){fill(255);}
     
     circle((this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2))*gg,this.radius*gg);
     line((this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)-(this.radius/3))*gg,(this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)+(this.radius/3))*gg);
     line((this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)-(this.radius/3))*gg,(this.xPos+(etagenhoehe/10*2)-(this.radius/4))*gg,(this.yPos+(this.etagenhoehe/2)-(this.radius/3)+(this.radius/4))*gg);
     line((this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)-(this.radius/3))*gg,(this.xPos+(etagenhoehe/10*2)+(this.radius/4))*gg,(this.yPos+(this.etagenhoehe/2)-(this.radius/3)+(this.radius/4))*gg);
     
     }
     //___________________________________________________RUFTASTE_________________AUF____________________(VISUELL_AN)____________WIRD_AUTOMATISCH_IN_ENDHALTESTELLE_AUFGERUFEN_________________ 
     if(this.etage===0 || (this.steuerungstyp===1 && this.etage<etagen.length-1)){//nur eine taste zeichnen
     if(dist(mausX,mausY,(this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2))*gg)<this.radius*gg/2){aussenauf[this.etage]=true;} 
     if(aussenauf[this.etage]){fill(0,255,0);}
     if(!aussenauf[this.etage]){fill(255);}
     
     circle((this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2))*gg,this.radius*gg);
     line((this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)-(this.radius/3))*gg,(this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)+(this.radius/3))*gg);
     line((this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)+(this.radius/3))*gg,(this.xPos+(etagenhoehe/10*2)-(this.radius/4))*gg,(this.yPos+(this.etagenhoehe/2)+(this.radius/3)-(this.radius/4))*gg);
     line((this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)+(this.radius/3))*gg,(this.xPos+(etagenhoehe/10*2)+(this.radius/4))*gg,(this.yPos+(this.etagenhoehe/2)+(this.radius/3)-(this.radius/4))*gg);
     
     }
     
     
     
     //_________________________________________________RUFTASTE_AUF_UND_AB__________________________________________________________________________________________________________________
     if(this.etage!=0 && this.etage!=etagen.length-1 && this.steuerungstyp===2){//zwei tasten zeichnen
       if(dist(mausX,mausY,(this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)-(this.etagenhoehe/8))*gg)<this.radius*gg/2){aussenab[this.etage]=true;}
       if(aussenab[this.etage]){fill(0,255,0);}
       if(!aussenab[this.etage]){fill(255);}
       
       circle((this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)-(this.etagenhoehe/8))*gg,this.radius*gg);
       line((this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)-(this.etagenhoehe/8)-(this.radius/3))*gg,(this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)-(this.etagenhoehe/8)+(this.radius/3))*gg);
       line((this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)-(this.etagenhoehe/8)-(this.radius/3))*gg,(this.xPos+(etagenhoehe/10*2)-(this.radius/4))*gg,(this.yPos+(this.etagenhoehe/2)-(this.etagenhoehe/8)-(this.radius/3)+(this.radius/4))*gg);
       line((this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)-(this.etagenhoehe/8)-(this.radius/3))*gg,(this.xPos+(etagenhoehe/10*2)+(this.radius/4))*gg,(this.yPos+(this.etagenhoehe/2)-(this.etagenhoehe/8)-(this.radius/3)+(this.radius/4))*gg);
       if(dist(mausX,mausY,(this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)+(this.etagenhoehe/8))*gg)<this.radius*gg/2){aussenauf[this.etage]=true;}
       if(aussenauf[this.etage]){fill(0,255,0);}
       if(!aussenauf[this.etage]){fill(255);}
       
       circle((this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)+(this.etagenhoehe/8))*gg,this.radius*gg);
       line((this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)+(this.etagenhoehe/8)-(this.radius/3))*gg,(this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)+(this.etagenhoehe/8)+(this.radius/3))*gg);
       line((this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)+(this.etagenhoehe/8)+(this.radius/3))*gg,(this.xPos+(etagenhoehe/10*2)-(this.radius/4))*gg,(this.yPos+(this.etagenhoehe/2)+(this.etagenhoehe/8)+(this.radius/3)-(this.radius/4))*gg);
       line((this.xPos+(etagenhoehe/10*2))*gg,(this.yPos+(this.etagenhoehe/2)+(this.etagenhoehe/8)+(this.radius/3))*gg,(this.xPos+(etagenhoehe/10*2)+(this.radius/4))*gg,(this.yPos+(this.etagenhoehe/2)+(this.etagenhoehe/8)+(this.radius/3)-(this.radius/4))*gg);
       
      
     }
     
     if(this.etage===standortDez && !doorOpened){this.open=doorOpen;this.close=!doorOpen;}//__________________________________oeffnungsanweisung durch steuerung bzw kabine. nur uebernehmen, wenn die kabinentuer noch nicht voll offen ist!
     if(this.etage!=standortDez && !this.manuellGeoeffnet){this.open=false;this.close=true;}//________________________________wenn keine kabine hinter der tuer ist und die tuer nicht manuell geoeffnet wurde, mache zu
          
     if(this.xPosTuer>this.xPos+(this.etagenhoehe/4) && this.open){this.xPosTuer--;}//________________________________________tuerbewegung
     if(this.xPosTuer<this.xPos+(this.etagenhoehe/10*7) && this.close){this.xPosTuer++;}
     if(this.xPosTuer<this.xPos+(this.etagenhoehe/10*7)){this.KTS=false;}else{this.KTS=true;}
     
      
   };
   
}

//__________________________________________________H_E_L_L_E_R___H_I_N_T_E_R_G_R_U_N_D__________________________________________
function Schachtlicht(a,b,c){
  
  rectMode(CORNER);
  noStroke();
  fill(233,237,177,lichtstaerke);
  rect((a-125)*gg,(b-10)*gg,(c+400)*gg,(c+20)*gg,50*gg);
  if(lichtstaerke<300 && schachtlicht){lichtstaerke+=10;}
  if(lichtstaerke>0 && !schachtlicht){lichtstaerke-=10;}
  
  
  
  
} 
  

//______________________________________________________F_A_H_R_K_O_R_B_________________________________________________________________________________________________________________
//a=xPos fahrkorb
//b=hoehe des fahrkorbs
//c=in dieser etage steht der fahrkorb zu beginn


function Fahrkorb(a,b,c)
{
  
this.xPos=a;
this.fahrkorbhoehe=b;
this.standortDez=c;
this.yPos=topfloor+(this.standortDez*this.fahrkorbhoehe);
this.strichdicke=5;
this.xPosTuer=this.xPos+(this.fahrkorbhoehe/2-15);
this.yPosTuer=this.yPos+(this.fahrkorbhoehe/15);
this.radius=10;
this.tuerOeffnen=false;
this.tuerSchliessen=false;





this.anzeigen=function()
   {
     
     
     rectMode(CORNERS);
     //stroke(255);
     //strokeWeight(this.strichdicke*gg);
     noStroke();
     //_______________________________________________________RAHMEN_________________________________________________________________________________________________________________________________________________
     fill(50);
     rect(this.xPos*gg,this.yPos*gg,(this.xPos+this.fahrkorbhoehe)*gg,(this.yPos+this.fahrkorbhoehe)*gg,10*gg);
     //___________________________________________________FAHRKORB_INNENLEBEN_______________________________________________________________________________________________________________________________________
     fill(255);
     rect((this.xPos+(this.fahrkorbhoehe/10))*gg,(this.yPos+(this.fahrkorbhoehe/10))*gg,(this.xPos+this.fahrkorbhoehe-(this.fahrkorbhoehe/10))*gg,(this.yPos+this.fahrkorbhoehe-(this.fahrkorbhoehe/10))*gg);
     strokeWeight(this.strichdicke*gg/2);
     stroke(0);
     line((this.xPos+this.fahrkorbhoehe-(this.fahrkorbhoehe/3))*gg,(this.yPos+this.fahrkorbhoehe-(this.fahrkorbhoehe/6))*gg,(this.xPos+this.fahrkorbhoehe)*gg,(this.yPos+this.fahrkorbhoehe-this.strichdicke)*gg);
     line((this.xPos+this.fahrkorbhoehe-(this.fahrkorbhoehe/3))*gg,(this.yPos+(this.fahrkorbhoehe/6))*gg,(this.xPos+this.fahrkorbhoehe)*gg,(this.yPos+this.strichdicke)*gg);
     
     fill(235);
     rect((this.xPos+(this.fahrkorbhoehe/4))*gg,(this.yPos+(this.fahrkorbhoehe/6))*gg,(this.xPos+this.fahrkorbhoehe-(this.fahrkorbhoehe/3))*gg,(this.yPos+this.fahrkorbhoehe-(this.fahrkorbhoehe/6))*gg);
     strokeWeight(this.strichdicke*gg*1);line((this.xPos+this.strichdicke+(this.fahrkorbhoehe/6))*gg,(this.yPos+(this.fahrkorbhoehe/2))*gg,(this.xPos+this.fahrkorbhoehe-this.strichdicke-(this.fahrkorbhoehe/3))*gg,(this.yPos+(this.fahrkorbhoehe/2))*gg);
     
     
     
     
     
     //_______________________________________________LINKE_WAND_______________________________________________________________________________________________________________________________________________________
     strokeWeight(this.strichdicke*gg/2);
     fill(100);
     rect((this.xPos+(this.fahrkorbhoehe/10))*gg,(this.yPos+(this.fahrkorbhoehe/10))*gg,(this.xPos+this.fahrkorbhoehe-(this.fahrkorbhoehe/1.7))*gg,(this.yPos+this.fahrkorbhoehe-(this.fahrkorbhoehe/10))*gg);
     //______________________________________________RECHTE_WAND_____________________________________________________________________
     rect((this.xPos+(this.fahrkorbhoehe-(this.fahrkorbhoehe/4.5)))*gg,(this.yPos+(this.fahrkorbhoehe/10))*gg,(this.xPos+this.fahrkorbhoehe-10)*gg,(this.yPos+this.fahrkorbhoehe-(this.fahrkorbhoehe/10))*gg);
     //________________________________________________KABINENTUER____________________________________________________________________________________________________________________________________________________
     fill(175);stroke(0);
     rect((this.xPosTuer)*gg,(this.yPosTuer)*gg,(this.xPosTuer+(this.fahrkorbhoehe/2)-(this.fahrkorbhoehe/10))*gg,(this.yPosTuer+this.fahrkorbhoehe-(2*(this.fahrkorbhoehe/15)))*gg);
     //_______________________________________________DACHAUFBAUTEN_________________________________________________________________________________________________________________________________________________
     stroke(80);strokeWeight(this.strichdicke*gg);
     line((this.xPos+(this.fahrkorbhoehe/10))*gg,this.yPos*gg,(this.xPos+(this.fahrkorbhoehe/10))*gg,(this.yPos-(this.fahrkorbhoehe/10*3))*gg);
     line((this.xPos+(this.fahrkorbhoehe/10*9))*gg,this.yPos*gg,(this.xPos+(this.fahrkorbhoehe/10*9))*gg,(this.yPos-(this.fahrkorbhoehe/10*3))*gg);    
     line((this.xPos)*gg,(this.yPos-(this.fahrkorbhoehe/10*3))*gg,(this.xPos+this.fahrkorbhoehe)*gg,(this.yPos-(this.fahrkorbhoehe/10*3))*gg);
     fill(215);noStroke();
     rect((this.xPos+(this.fahrkorbhoehe/10*6))*gg,(this.yPos)*gg,(this.xPos+(this.fahrkorbhoehe/10*8))*gg,(this.yPos-(this.fahrkorbhoehe/10*2))*gg);
     fill(255,255,0);
     rect((this.xPos+(this.fahrkorbhoehe/10*5.3))*gg,(this.yPos-(this.fahrkorbhoehe/10*3))*gg,(this.xPos+(this.fahrkorbhoehe/10*5.9))*gg,(this.yPos-(this.fahrkorbhoehe/10*0.5))*gg,5*gg);
     fill(255,0,0);
     circle((this.xPos+(this.fahrkorbhoehe/10*5.6))*gg,(this.yPos-(this.fahrkorbhoehe/10*2.7))*gg,(this.radius/10*(this.fahrkorbhoehe/25))*gg);
     fill(0);
     circle((this.xPos+(this.fahrkorbhoehe/10*5.6))*gg,(this.yPos-(this.fahrkorbhoehe/10*2.2))*gg,(this.radius/10*(this.fahrkorbhoehe/25))*gg);
     circle((this.xPos+(this.fahrkorbhoehe/10*5.6))*gg,(this.yPos-(this.fahrkorbhoehe/10*1.3))*gg,(this.radius/10*(this.fahrkorbhoehe/25))*gg);
     fill(255);
     circle((this.xPos+(this.fahrkorbhoehe/10*5.6))*gg,(this.yPos-(this.fahrkorbhoehe/10*1.8))*gg,(this.radius/10*(this.fahrkorbhoehe/25))*gg);
     fill(0,0,255);
     circle((this.xPos+(this.fahrkorbhoehe/10*5.6))*gg,(this.yPos-(this.fahrkorbhoehe/10*0.8))*gg,(this.radius/10*(this.fahrkorbhoehe/25))*gg);
     
     
     this.yPosTuer=this.yPos+(this.fahrkorbhoehe/15);
     if(doorOpen && this.xPosTuer>this.xPos){this.xPosTuer--;}
     if(this.xPosTuer>this.xPos){doorOpened=false;}else{doorOpened=true;}
     if(this.xPosTuer<this.xPos+(this.fahrkorbhoehe/2-15) && !doorOpen){this.xPosTuer++;}
     if(this.xPosTuer<this.xPos+(this.fahrkorbhoehe/2-15)){doorClosed=false;}else{doorClosed=true;}
      if(this.xPosTuer<this.xPos+(this.fahrkorbhoehe/2-15)){KTC=false;}else{KTC=true;}
      
      
   };


}

//__________________________________________________G_E_G_E_N_G_E_W_I_C_H_T______________________________________________________________________________________________________________________________
// nur positionsangaben erforderlich. hoehendaten werden vom fahrkorbstand abgeleitet

function Gegengewicht(a,b)
{
  this.xPos=a;
  this.yPos=map(fahrkorb.yPos,0,750,750,0);
  
  
  
  
  
this.anzeigen=function()
   {  
  
     
     this.yPos=map(fahrkorb.yPos,250,etagen[etagen.length-1].yPos,etagen[etagen.length-1].yPos,250);
  rectMode(CORNERS);
  fill(100);
  stroke(0);
  strokeWeight(strichdicke*gg/2);
  rect(this.xPos*gg,this.yPos*gg,(this.xPos+20)*gg,(this.yPos+etagenhoehe)*gg,5*gg);
  
  
  
  };
  
  
  
}


//________________________________________I_N_N_E_N_T_A_B_L_O_______________________________________________________________________________________________________________________________________


// a und b fuer die position MITTE tablo
// c uebergibt die anzahl der etagen und somit auch die hoehe des tablos

function Innentablo(a,b,c){
  
  this.xPos=a;
  this.yPos=b;
  this.etagenanzahl=c;
  this.radius=50;
  this.tablohoehe=(this.etagenanzahl+3)*this.radius;
  this.tablobreite=this.radius*2;
  this.anzeige=0;
  
  
  
  
  
 this.anzeigen=function()
   { 
    
     this.anzeige=etagenname[standortDez];
     rectMode(CORNERS);
     stroke(0);
     strokeWeight(strichdicke*gg/2);
     fill(200);
     rect(this.xPos*gg,this.yPos*gg,(this.xPos+this.tablobreite)*gg,(this.yPos+this.tablohoehe)*gg,10*gg);//__________________________________________________________________________zeichne tablo hintergrund
     strokeWeight(strichdicke*gg);
     for(f=0;f<this.etagenanzahl;f++){
     if(dist(mausX,mausY,(this.xPos+(this.radius))*gg,(this.yPos+(2*this.radius)+(this.radius*f))*gg)<this.radius/2*gg){innen[f]=true;}//_______________________________________________________________kommando
     if(innen[f]){stroke(0,255,0);}else{stroke(255);}//____________________________________________________________________________________________________________________________________quittierung
     fill(230);
     circle((this.xPos+(this.radius))*gg,(this.yPos+(2*this.radius)+(this.radius*f))*gg,this.radius*gg*0.9);//_________________________________________________________________________________zeichne tasten
     textFont('Helvetica');textSize(20*gg);textAlign(CENTER,CENTER);noStroke();fill(0);
     text(etagenname[f],(this.xPos+this.radius)*gg,(this.yPos+(2*this.radius)+(this.radius*f))*gg);//___________________________________________________________________________________schreibe etagennamen auf taste  
     }
     stroke(0);
     rect((this.xPos+(this.tablobreite/10*1))*gg,(this.yPos+(this.radius*1))*gg,(this.xPos+(this.tablobreite/10*9))*gg,(this.yPos+(this.radius/10*2))*gg,5*gg);//_________________________________________________________________zeichne display
     textFont(dotmatrix);fill(255,0,0);textSize(30*gg);textAlign(CENTER,CENTER);
     text(this.anzeige,(this.xPos+(this.tablobreite/2))*gg,(this.yPos+(this.radius*0.60))*gg);//_________________________________________________________________________________schreibe standort
     fill(230);
     if(dist(mausX,mausY,(this.xPos+this.radius)*gg,(this.yPos+this.radius+(this.radius*(this.etagenanzahl+1)))*gg)<this.radius/2*gg && ((stopp && tuerzone)||!doorClosed) && !tuerenBleibenZu && tuerzone && !inspektionAktiv)//tuerauf-taster abfragen
     {stroke(0,255,0);doorOpen=true;timer=millis()+5000;}else{stroke(255);}
     circle((this.xPos+this.radius)*gg,(this.yPos+this.radius+(this.radius*(this.etagenanzahl+1)))*gg,this.radius*gg*0.9);// tuerauf-taster zeichnen
     textFont('Helvetica');textSize(20*gg);textAlign(CENTER,CENTER);noStroke();fill(0);
     text("< >",(this.xPos+this.radius)*gg,(this.yPos+this.radius+(this.radius*(1+this.etagenanzahl)))*gg);
  
  
  
  };
  
}
