

function Anfangsmenu ()
{
 
  //background(255);
  
  
  
}
