

function Mainboard(a,b){
  
  
 this.xPos=a;
 this.yPos=b;
 this.gedrueckt=false;
 this.hoehe=250;
 this.breite=350;
 this.xPosDisplay=this.xPos+(this.breite/10);
 this.yPosDisplay=this.yPos+(this.hoehe/2);
 this.radius=40;
 this.menu=[];
 //this.menu[0]="Innenruf";
 //this.menu[1]="Anhalteweg";
 //this.menu[2]="Tueren sperren";
 //this.menu[3]="Rufe sperren";
 //this.menu[4]="Schachtlicht";
 this.menupunkt=0;
 this.timer=millis();
 this.wartezeit=1000;//wartezeit bis zum schnellen laufen der zahlen
 this.plus=false;
 this.minus=false;
 
 
 
 
 
 this.anzeigen=function(){
   
   
 this.menu[0]="Innenruf";
 this.menu[1]="Anhalteweg: "+verzoegerungsweg;
 if(tuerenBleibenZu){this.menu[2]="Tueren gesperrt";}else{this.menu[2]="Tueren normal";}
 if(aussenEin){this.menu[3]="Aussenrufe JA";}else{this.menu[3]="Aussenrufe NEIN";}
 if(schachtlicht){this.menu[4]="Licht AN";} else{this.menu[4]="Licht AUS";}
   
   rectMode(CORNER);
   fill(255);
   stroke(0);
   strokeWeight(strichdicke*gg);
   rect(this.xPos*gg,this.yPos*gg,this.breite*gg,this.hoehe*gg,20*gg);
   
  textFont('Helvetica');textSize(30*gg);textAlign(CENTER,TOP);
  noStroke();fill(255,0,0);
  text("Beispiel Steuerung",(this.xPos+(this.breite/2))*gg,(this.yPos+(this.hoehe/20))*gg);
  textSize(15*gg);textAlign(LEFT);
  text("     Passiv     Insp   KabTür  Schachttür",(this.xPos)*gg,(this.yPos+50)*gg);
  if(endschalterOben && endschalterUnten && GBkontakt && spanngewicht){fill(0,255,0);}else{fill(255,0,0);}
  stroke(0);strokeWeight(strichdicke/4*gg);
  circle((this.xPos+50)*gg,(this.yPos+80)*gg,this.radius*gg/4);
  if(!inspektionsfahrtenSI){fill(255,0,0);}
  circle((this.xPos+100)*gg,(this.yPos+80)*gg,this.radius*gg/4);
  if(!KTC){fill(255,0,0);}
  circle((this.xPos+150)*gg,(this.yPos+80)*gg,this.radius*gg/4);
  if(!aktiverSI){fill(255,0,0);}
  circle((this.xPos+200)*gg,(this.yPos+80)*gg,this.radius*gg/4);
  
  
   stroke(0);strokeWeight(strichdicke/2*gg);fill(220);   
   rect(this.xPosDisplay*gg,this.yPosDisplay*gg,this.breite/2*gg,this.hoehe/5*gg,10*gg);
   stroke(0);textAlign(LEFT);textFont('Helvetica');textSize(15*gg);
   textFont(dotmatrix);strokeWeight(1);fill(150);
   text(this.menu[this.menupunkt],(this.xPosDisplay+(this.breite/60))*gg,((this.yPosDisplay)+(this.hoehe/15))*gg);
   
   
  
  
   
    //_______________________taste_menuauswahl__________________________________________
   push();
   fill(170,210,240);stroke(0);
   translate((this.xPosDisplay+(this.radius/2))*gg,this.yPosDisplay*1.5*gg);
   textSize(12*gg);
   if(dist(mausX,mausY,(this.xPosDisplay+(this.radius/2))*gg,this.yPosDisplay*1.5*gg)<this.radius*gg/2 && !this.gedrueckt){this.menupunkt++;this.gedrueckt=true;if(this.menupunkt>this.menu.length-1){this.menupunkt=0;}}
   if(dist(mausX,mausY,(this.xPosDisplay+(this.radius/2))*gg,this.yPosDisplay*1.5*gg)<this.radius*gg/2 && this.gedrueckt){textSize(10*gg);}
   circle(0,0,this.radius*gg);
   textFont('Helvetica');
   
   textAlign(CENTER,CENTER);
   noStroke();fill(0);text("MENU",0,0);
   
   pop();
   
   push();
   fill(170,210,240);stroke(0);
   translate((this.xPosDisplay+(this.breite/4))*gg,this.yPosDisplay*1.5*gg);
   textSize(30*gg);
   if(!this.gedrueckt){this.timer=millis()+this.wartezeit;}
   if(dist(mausX,mausY,(this.xPosDisplay+(this.breite/4))*gg,this.yPosDisplay*1.5*gg)<this.radius*gg/2 && (!this.gedrueckt || this.timer<millis()) ){this.gedrueckt=true;this.plus=true;}
   if(dist(mausX,mausY,(this.xPosDisplay+(this.breite/4))*gg,this.yPosDisplay*1.5*gg)<this.radius*gg/2 && this.gedrueckt){textSize(20*gg);}
   circle(0,0,this.radius*gg);
   textFont('Helvetica');
   textAlign(CENTER,CENTER);
   noStroke();fill(0);text("+",0,0);
   
   pop();
   
   push();
   fill(170,210,240);stroke(0);
   textSize(30*gg);
   if(!this.gedrueckt){this.timer=millis()+this.wartezeit;}
   if(dist(mausX,mausY,(this.xPosDisplay+(this.breite/2)-(this.radius/2))*gg,this.yPosDisplay*1.5*gg)<this.radius*gg/2 && (!this.gedrueckt || this.timer<millis()) ){this.gedrueckt=true;this.minus=true;}
   if(dist(mausX,mausY,(this.xPosDisplay+(this.breite/2)-(this.radius/2))*gg,this.yPosDisplay*1.5*gg)<this.radius*gg/2 && this.gedrueckt){textSize(20*gg);}
   circle((this.xPosDisplay+(this.breite/2)-(this.radius/2))*gg,this.yPosDisplay*1.5*gg,this.radius*gg);
   textFont('Helvetica');textAlign(CENTER,CENTER);
   noStroke();fill(0);text("-",(this.xPosDisplay+(this.breite/2)-(this.radius/2))*gg,this.yPosDisplay*1.5*gg);
   
   pop();
   
   if(this.menupunkt===0 && this.plus){this.plus=false;innen[0]=true;}
   if(this.menupunkt===0 && this.minus){this.minus=false;innen[innen.length-1]=true;}
   if(this.menupunkt===1 && this.plus){this.plus=false;if(verzoegerungsweg<100){verzoegerungsweg++;}}
   if(this.menupunkt===1 && this.minus){this.minus=false;if(verzoegerungsweg>20){verzoegerungsweg--;}}
   if(this.menupunkt===2 && (this.plus||this.minus)){this.plus=false;this.minus=false;tuerenBleibenZu=!tuerenBleibenZu;}
   if(this.menupunkt===3 && (this.plus||this.minus)){this.plus=false;this.minus=false;aussenEin=!aussenEin;}
   if(this.menupunkt===4 && (this.plus||this.minus)){this.plus=false;this.minus=false;schachtlicht=!schachtlicht;}
   
   
   
   
   
   
   
   
   
 };
 
}
  
 //_________________________________________________________V_I_S_U_A_L_I_S_I_E_R_U_N_G___R_E_G_E_L_G_E_R_A_E_T___________________________________________
 
 function Reglung(a,b){
 this.xPos=a;
 this.yPos=b;
 this.gedrueckt=false;
 this.hoehe=250;
 this.breite=350;
 this.xPosDisplay=this.xPos+(this.breite/10);
 this.yPosDisplay=this.yPos+(this.hoehe/2);
 this.radius=40;
 this.menu=[];
 this.menu[0]="Aktuell= ";
 this.menu[1]="V max= ";
 this.menu[2]="V1= ";
 this.menu[3]="Vinsp= ";
 this.menu[4]="Beschl.= ";
 this.menu[5]="Verz.= ";
 this.menu[6]="V1 auf 0= ";
 this.menupunkt=0;
 this.timer=millis();   
 this.wartezeit=1000; 
 this.wert=0;//gerundeter wwert der abgerufenen daten fuer die anzeige
 this.plus=false;
 this.minus=false;
    
    
    
    
    
    
    
    this.anzeigen= function(){
      
      
 
      
   rectMode(CORNER);
   fill(255,0,0);
   stroke(0);
   strokeWeight(strichdicke*gg);
   rect(this.xPos*gg,this.yPos*gg,this.breite*gg,this.hoehe*gg,20*gg);
      
  textFont('Helvetica');textSize(30*gg);textAlign(CENTER,TOP);
  noStroke();fill(255);
  text("Beispiel Regelung",(this.xPos+(this.breite/2))*gg,(this.yPos+(this.hoehe/20))*gg); 
      
   stroke(0);strokeWeight(strichdicke/2*gg);fill(220);   
   rect(this.xPosDisplay*gg,this.yPosDisplay*gg,this.breite/2*gg,this.hoehe/5*gg,10*gg);   
    stroke(0);textAlign(LEFT);textFont('Helvetica');textSize(15*gg);
   textFont(dotmatrix);strokeWeight(1);fill(150);
   this.wert=(round(umrichterdaten[this.menupunkt]*100))/100;
   text(this.menu[this.menupunkt]+this.wert,(this.xPosDisplay+(this.breite/60))*gg,((this.yPosDisplay)+(this.hoehe/15))*gg);
   
   
   
   //_______________________taste_menuauswahl__________________________________________
   fill(170,210,240);stroke(0);
   circle((this.xPosDisplay+(this.radius/2))*gg,this.yPosDisplay*1.5*gg,this.radius*gg);
   textFont('Helvetica');textSize(12*gg);textAlign(CENTER,CENTER);
   //noStroke();fill(0);text("MENU",(this.xPosDisplay+(this.radius/2))*gg,this.yPosDisplay*1.5*gg);
   if(dist(mausX,mausY,(this.xPosDisplay+(this.radius/2))*gg,this.yPosDisplay*1.5*gg)<this.radius*gg/2 && !this.gedrueckt){this.menupunkt++;this.gedrueckt=true;if(this.menupunkt>this.menu.length-1){this.menupunkt=0;}}
   if(dist(mausX,mausY,(this.xPosDisplay+(this.radius/2))*gg,this.yPosDisplay*1.5*gg)<this.radius*gg/2 && this.gedrueckt){textSize(10*gg);}
   noStroke();fill(0);text("MENU",(this.xPosDisplay+(this.radius/2))*gg,this.yPosDisplay*1.5*gg);
   
   fill(170,210,240);stroke(0);
   circle((this.xPosDisplay+(this.breite/4))*gg,this.yPosDisplay*1.5*gg,this.radius*gg);
   textFont('Helvetica');textSize(30*gg);textAlign(CENTER,CENTER);
   noStroke();fill(0);
   if(!this.gedrueckt){this.timer=millis()+this.wartezeit;}
   if(dist(mausX,mausY,(this.xPosDisplay+(this.breite/4))*gg,this.yPosDisplay*1.5*gg)<this.radius*gg/2 && (!this.gedrueckt || this.timer<millis()) && this.menupunkt!=0){this.gedrueckt=true;this.plus=true;}
   if(dist(mausX,mausY,(this.xPosDisplay+(this.breite/4))*gg,this.yPosDisplay*1.5*gg)<this.radius*gg/2 && this.gedrueckt){textSize(20*gg);}
   text("+",(this.xPosDisplay+(this.breite/4))*gg,this.yPosDisplay*1.5*gg);
   
   
   fill(170,210,240);stroke(0);
   circle((this.xPosDisplay+(this.breite/2)-(this.radius/2))*gg,this.yPosDisplay*1.5*gg,this.radius*gg);
   textFont('Helvetica');textSize(30*gg);textAlign(CENTER,CENTER);
   noStroke();fill(0);
   if(!this.gedrueckt){this.timer=millis()+this.wartezeit;}
   if(dist(mausX,mausY,(this.xPosDisplay+(this.breite/2)-(this.radius/2))*gg,this.yPosDisplay*1.5*gg)<this.radius*gg/2 && (!this.gedrueckt || this.timer<millis())&& this.menupunkt!=0){this.gedrueckt=true;this.minus=true;}
   if(dist(mausX,mausY,(this.xPosDisplay+(this.breite/2)-(this.radius/2))*gg,this.yPosDisplay*1.5*gg)<this.radius*gg/2 && this.gedrueckt){textSize(20*gg);}
   text("-",(this.xPosDisplay+(this.breite/2)-(this.radius/2))*gg,this.yPosDisplay*1.5*gg);
   
   
   if(this.menupunkt===1 && this.plus){this.plus=false;if(umrichterdaten[1]<2){umrichterdaten[1]+=0.1;}}
   if(this.menupunkt===1 && this.minus){this.minus=false;if(umrichterdaten[1]>0){umrichterdaten[1]-=0.1;}}
   if(this.menupunkt===2 && this.plus){this.plus=false;umrichterdaten[2]+=0.1;if(umrichterdaten[2]>1){umrichterdaten[2]=1;}}
   if(this.menupunkt===2 && this.minus){this.minus=false;umrichterdaten[2]-=0.1;if(umrichterdaten[2]<0){umrichterdaten[2]=0;}}
   if(this.menupunkt===3 && this.plus){this.plus=false;umrichterdaten[3]+=0.1;if(umrichterdaten[3]>1){umrichterdaten[3]=1;}}
   if(this.menupunkt===3 && this.minus){this.minus=false;umrichterdaten[3]-=0.1;if(umrichterdaten[3]<0){umrichterdaten[3]=0;}}
   if(this.menupunkt===4 && this.plus){this.plus=false;umrichterdaten[4]+=0.1;if(umrichterdaten[4]>100){umrichterdaten[4]=100;}}
   if(this.menupunkt===4 && this.minus){this.minus=false;umrichterdaten[4]-=0.1;if(umrichterdaten[4]<10){umrichterdaten[4]=10;}}
   if(this.menupunkt===5 && this.plus){this.plus=false;umrichterdaten[5]+=0.1;if(umrichterdaten[5]>100){umrichterdaten[5]=100;}}
   if(this.menupunkt===5 && this.minus){this.minus=false;umrichterdaten[5]-=0.1;if(umrichterdaten[5]<10){umrichterdaten[5]=10;}}
   if(this.menupunkt===6 && this.plus){this.plus=false;umrichterdaten[6]+=0.1;if(umrichterdaten[6]>50){umrichterdaten[6]=50;}}
   if(this.menupunkt===6 && this.minus){this.minus=false;umrichterdaten[6]-=0.1;if(umrichterdaten[6]<1){umrichterdaten[6]=1;}}
  
   
   
   
      
    };
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
